/*
  PUSHPAK UAV IDS - MAVLink command/context anomaly detector

  Defensive inspection of commands after MAVLink parsing. It does not block or
  alter the command; it emits an evidence candidate for correlation.
*/
#pragma once

#include <stdint.h>

#include "AP_IDS.h"

#if AP_IDS_ENABLED

class CommandDetector
{
public:
    static constexpr uint8_t PARAM_COUNT = 7;
    static constexpr uint8_t MAX_SOURCES = 8;
    static constexpr uint8_t MAX_COMMAND_PROFILES = 16;

    struct Observation {
        uint32_t time_ms;
        uint16_t command_id;
        uint8_t source_sysid;
        uint8_t source_compid;
        uint8_t target_sysid;
        uint8_t target_compid;
        uint8_t confirmation;
        bool source_trusted;
        bool vehicle_armed;
        bool vehicle_airborne;
        bool mission_running;
        bool external_control_expected;
        float params[PARAM_COUNT];
    };

    struct Result {
        uint16_t evidence;
        float confidence;
        float source_score;
        float context_score;
        float burst_score;
        float parameter_score;
        float replay_score;
        uint16_t command_id;
    };

    CommandDetector();

    void reset();
    Result observe(const Observation &obs);

    const Result &result() const { return _result; }

private:
    struct SourceProfile {
        bool active;
        uint8_t sysid;
        uint8_t compid;
        uint32_t last_command_ms;
        uint16_t command_count;
    };

    struct CommandProfile {
        bool active;
        uint16_t command_id;
        uint32_t last_seen_ms;
        uint16_t count;
        float interarrival_ewma_ms;
        float interarrival_var_ms2;
        float burst_cusum;
        float parameter_mean[PARAM_COUNT];
        float parameter_m2[PARAM_COUNT];
        uint16_t parameter_samples;
    };

    SourceProfile *find_source(uint8_t sysid, uint8_t compid, uint32_t now_ms, bool create);
    CommandProfile *find_command(uint16_t command_id, uint32_t now_ms, bool create);

    static float clamp01(float x);
    static bool nearly_equal(float a, float b, float tolerance);
    static bool is_sensitive_command(uint16_t command_id);

    float update_burst(CommandProfile &profile, uint32_t now_ms);
    float update_parameter_baseline(CommandProfile &profile, const float *params);
    float context_anomaly(const Observation &obs) const;

    SourceProfile _sources[MAX_SOURCES];
    CommandProfile _commands[MAX_COMMAND_PROFILES];
    Result _result;
};

#endif // AP_IDS_ENABLED
