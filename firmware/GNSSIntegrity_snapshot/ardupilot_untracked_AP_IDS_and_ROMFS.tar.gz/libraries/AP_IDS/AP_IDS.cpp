/*
  PUSHPAK UAV IDS - shared evidence/state implementation
*/
#include "AP_IDS.h"

#if AP_IDS_ENABLED

#include "GPSDetector.h"
#include "IMUDetector.h"
#include "MissionDetector.h"
#include "AP_IDSGCS.h"
#include <AP_AHRS/AP_AHRS.h>
#include <AP_GPS/AP_GPS.h>
#include <AP_InertialSensor/AP_InertialSensor.h>
#include <AP_Mission/AP_Mission.h>
#include <AP_Arming/AP_Arming.h>
#include <AP_Vehicle/AP_Vehicle.h>
#include <math.h>

AP_IDS *AP_IDS::_singleton = nullptr;

AP_IDS::AP_IDS() :
    _event_head(0),
    _event_count(0),
    _event_sequence(0),
    _initialised(false)
{
    for (uint8_t i = 0; i < static_cast<uint8_t>(Detector::COUNT); i++) {
        _channels[i] = ChannelState {
            State::CLEAR,
            EVID_NONE,
            0.0f,
            0.0f,
            0,
            0
        };
    }

    for (uint8_t i = 0; i < EVENT_RING_SIZE; i++) {
        _events[i] = Event {
            0,
            Detector::GPS,
            State::CLEAR,
            EVID_NONE,
            0.0f,
            0.0f,
            0,
            {0, 0, 0}
        };
    }

    if (_singleton == nullptr) {
        _singleton = this;
    }
}

AP_IDS *AP_IDS::get_singleton()
{
    return _singleton;
}

namespace AP {
AP_IDS &ids()
{
    return *AP_IDS::get_singleton();
}
}

float AP_IDS::clamp01(float value)
{
    if (value < CONFIDENCE_MIN) {
        return CONFIDENCE_MIN;
    }
    if (value > CONFIDENCE_MAX) {
        return CONFIDENCE_MAX;
    }
    return value;
}

void AP_IDS::init()
{
    _initialised = true;
#if AP_IDS_GNSSINT_ENABLED
    gnss_integrity.init();
#endif
}

void AP_IDS::update()
{
    if (!_initialised) {
        init();
    }
#if AP_IDS_GNSSINT_ENABLED
    gnss_integrity.update_logging(0);   // bounded: 1 Hz plus transitions
#endif

    AP_AHRS *ahrs = AP_AHRS::get_singleton();
    if (ahrs == nullptr) {
        return;
    }

    static GPSDetector gps_detector;
    const GPSDetector::Result gps_result = gps_detector.update(AP::gps(), *ahrs);
    if (gps_result.valid) {
        State gps_state = State::CLEAR;
        if (gps_result.persistence >= 5U) {
            gps_state = State::CONFIRMED;
        } else if (gps_result.confidence >= 0.55f) {
            gps_state = State::SUSPECTED;
        }

        publish(Detector::GPS,
                gps_state,
                gps_result.evidence,
                gps_result.confidence,
                gps_result.position_residual_m,
                AP::gps().primary_sensor());
    }

    static IMUDetector imu_detector;
    AP_InertialSensor *ins = AP_InertialSensor::get_singleton();
    if (ins != nullptr) {
        const IMUDetector::Result imu_result = imu_detector.update(*ins);
        State imu_state = State::CLEAR;
        if (imu_result.confidence >= 0.75f) {
            imu_state = State::CONFIRMED;
        } else if (imu_result.confidence >= 0.45f) {
            imu_state = State::SUSPECTED;
        }
        publish(Detector::IMU,
                imu_state,
                imu_result.evidence,
                imu_result.confidence,
                fmaxf(imu_result.accel_divergence, imu_result.gyro_divergence),
                imu_result.accel_outlier != 255U ? imu_result.accel_outlier : imu_result.gyro_outlier);
    }

    static MissionDetector mission_detector;
    AP_Mission *mission = AP_Mission::get_singleton();
    if (mission != nullptr) {
        // Flight-context weighting is supplied by the Copter integration hook
        // in the next stage. The detector remains useful pre-arm because it
        // fingerprints the mission independently.
        const AP_Vehicle *vehicle = AP::vehicle();
        const bool in_auto = vehicle != nullptr && vehicle->get_mode() == 3;   // Copter AUTO
        const MissionDetector::Result mission_result =
            mission_detector.update(*mission, AP::arming().is_armed(), in_auto);
        State mission_state = State::CLEAR;
        if (mission_result.confidence >= 0.75f) {
            mission_state = State::CONFIRMED;
        } else if (mission_result.confidence >= 0.45f) {
            mission_state = State::SUSPECTED;
        }
        publish(Detector::MISSION,
                mission_state,
                mission_result.evidence,
                mission_result.confidence,
                mission_result.mission_change_score,
                0);
    }

    update_adapters();
}

void AP_IDS::publish(Detector detector,
                     State state_value,
                     uint16_t evidence_value,
                     float confidence_value,
                     float primary_metric,
                     uint8_t source_instance)
{
    const uint8_t index = static_cast<uint8_t>(detector);
    const uint8_t count = static_cast<uint8_t>(Detector::COUNT);
    if (index >= count) {
        return;
    }

    const uint32_t now_ms = AP_HAL::millis();
    const float bounded_confidence = clamp01(confidence_value);

    ChannelState &channel = _channels[index];
    const bool materially_changed =
        (channel.state != state_value) ||
        (channel.evidence != evidence_value) ||
        (channel.source_instance != source_instance);

    channel.state = state_value;
    channel.evidence = evidence_value;
    channel.confidence = bounded_confidence;
    channel.primary_metric = primary_metric;
    channel.last_update_ms = now_ms;
    channel.source_instance = source_instance;

    // Avoid flooding the ring with identical steady-state observations.
    // Significant state/evidence changes are always retained, while an active
    // event can still refresh its timestamp/score through the channel state.
    if (!materially_changed) {
        return;
    }

    Event &slot = _events[_event_head];
    slot.time_ms = now_ms;
    slot.detector = detector;
    slot.state = state_value;
    slot.evidence = evidence_value;
    slot.confidence = bounded_confidence;
    slot.primary_metric = primary_metric;
    slot.source_instance = source_instance;
    slot.reserved[0] = 0;
    slot.reserved[1] = 0;
    slot.reserved[2] = 0;

    _event_head = static_cast<uint8_t>((_event_head + 1U) % EVENT_RING_SIZE);
    if (_event_count < EVENT_RING_SIZE) {
        _event_count++;
    }
    _event_sequence++;
}


bool AP_IDS::report_confirmed(const char *detector,
                              uint8_t level,
                              float confidence_value,
                              uint16_t evidence_value,
                              float primary_metric,
                              uint8_t source_instance,
                              uint32_t event_id)
{
    if (!_initialised) {
        return false;
    }
    return AP_IDSGCS::report_confirmed(detector, level, confidence_value, evidence_value,
                                       primary_metric, source_instance, event_id);
}

float AP_IDS::gps_confidence() const { return confidence(Detector::GPS); }
uint16_t AP_IDS::gps_evidence() const { return evidence(Detector::GPS); }
uint8_t AP_IDS::gps_state() const { return static_cast<uint8_t>(state(Detector::GPS)); }
float AP_IDS::mavlink_confidence() const { return confidence(Detector::MAVLINK); }
uint16_t AP_IDS::mavlink_evidence() const { return evidence(Detector::MAVLINK); }
uint8_t AP_IDS::mavlink_state() const { return static_cast<uint8_t>(state(Detector::MAVLINK)); }
float AP_IDS::command_confidence() const { return confidence(Detector::COMMAND); }
uint16_t AP_IDS::command_evidence() const { return evidence(Detector::COMMAND); }
uint8_t AP_IDS::command_state() const { return static_cast<uint8_t>(state(Detector::COMMAND)); }
float AP_IDS::rc_confidence() const { return confidence(Detector::RC_LINK); }
uint16_t AP_IDS::rc_evidence() const { return evidence(Detector::RC_LINK); }
uint8_t AP_IDS::rc_state() const { return static_cast<uint8_t>(state(Detector::RC_LINK)); }
float AP_IDS::imu_confidence() const { return confidence(Detector::IMU); }
uint16_t AP_IDS::imu_evidence() const { return evidence(Detector::IMU); }
float AP_IDS::mission_confidence() const { return confidence(Detector::MISSION); }
uint16_t AP_IDS::mission_evidence() const { return evidence(Detector::MISSION); }
uint8_t AP_IDS::mission_state() const { return static_cast<uint8_t>(state(Detector::MISSION)); }
float AP_IDS::parameter_confidence() const { return confidence(Detector::PARAMETER); }
uint16_t AP_IDS::parameter_evidence() const { return evidence(Detector::PARAMETER); }
uint8_t AP_IDS::parameter_state() const { return static_cast<uint8_t>(state(Detector::PARAMETER)); }
float AP_IDS::offboard_confidence() const { return confidence(Detector::OFFBOARD); }
uint16_t AP_IDS::offboard_evidence() const { return evidence(Detector::OFFBOARD); }
uint8_t AP_IDS::offboard_state() const { return static_cast<uint8_t>(state(Detector::OFFBOARD)); }

AP_IDS::State AP_IDS::state(Detector detector) const
{
    const uint8_t index = static_cast<uint8_t>(detector);
    if (index >= static_cast<uint8_t>(Detector::COUNT)) {
        return State::CLEAR;
    }
    return _channels[index].state;
}

float AP_IDS::confidence(Detector detector) const
{
    const uint8_t index = static_cast<uint8_t>(detector);
    if (index >= static_cast<uint8_t>(Detector::COUNT)) {
        return 0.0f;
    }
    return _channels[index].confidence;
}

uint16_t AP_IDS::evidence(Detector detector) const
{
    const uint8_t index = static_cast<uint8_t>(detector);
    if (index >= static_cast<uint8_t>(Detector::COUNT)) {
        return EVID_NONE;
    }
    return _channels[index].evidence;
}

uint32_t AP_IDS::last_update_ms(Detector detector) const
{
    const uint8_t index = static_cast<uint8_t>(detector);
    if (index >= static_cast<uint8_t>(Detector::COUNT)) {
        return 0;
    }
    return _channels[index].last_update_ms;
}

bool AP_IDS::get_channel(uint8_t detector, uint8_t &state_out, float &confidence_out, uint16_t &evidence_out) const
{
    if (detector >= static_cast<uint8_t>(Detector::COUNT)) {
        return false;
    }
    const ChannelState &c = _channels[detector];
    state_out = static_cast<uint8_t>(c.state);
    confidence_out = c.confidence;
    evidence_out = c.evidence;
    return true;
}

bool AP_IDS::get_latest_event(Event &event) const
{
    if (_event_count == 0) {
        return false;
    }

    const uint8_t latest = static_cast<uint8_t>(
        (_event_head + EVENT_RING_SIZE - 1U) % EVENT_RING_SIZE);
    event = _events[latest];
    return true;
}

#endif // AP_IDS_ENABLED
