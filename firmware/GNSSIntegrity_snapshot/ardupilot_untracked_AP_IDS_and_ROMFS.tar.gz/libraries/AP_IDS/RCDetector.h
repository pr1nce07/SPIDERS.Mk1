/*
  PUSHPAK UAV IDS - RC / telemetry-link anomaly detector

  Correlates link-quality degradation with RC loss, telemetry loss and
  heartbeat timing. The detector only reports evidence; it never changes
  failsafe or link configuration.
*/
#pragma once

#include <stdint.h>

#include "AP_IDS.h"

#if AP_IDS_ENABLED

class RCDetector
{
public:
    struct Observation {
        uint32_t time_ms;
        float link_quality;          // normalized 0..1
        float rc_loss_ratio;         // normalized 0..1
        float telemetry_loss_ratio;  // normalized 0..1
        uint16_t heartbeat_gap_ms;
        uint16_t rc_frame_loss_delta;
        uint16_t telemetry_drop_delta;
        bool rc_link_active;
        bool telemetry_link_active;
        bool failsafe_active;
    };

    struct Result {
        uint16_t evidence;
        float confidence;
        float gradual_degradation;
        float sudden_loss;
        float cross_link_mismatch;
        float heartbeat_anomaly;
        float quality_anomaly;
    };

    RCDetector();
    void reset();
    Result observe(const Observation &obs);

    const Result &result() const { return _result; }

private:
    static float clamp01(float x);

    float _quality_ewma;
    float _quality_var;
    float _quality_cusum;
    float _loss_ewma;
    float _loss_cusum;
    uint32_t _last_ms;
    uint8_t _degradation_persistence;
    bool _initialised;
    Result _result;
};

#endif // AP_IDS_ENABLED
