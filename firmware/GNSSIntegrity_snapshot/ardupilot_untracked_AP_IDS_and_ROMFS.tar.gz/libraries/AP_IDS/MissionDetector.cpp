/*
  PUSHPAK UAV IDS - mission integrity detector

  Detection methods:
    1. Mission fingerprinting with a compact FNV-1a hash over stored mission
       items. A same-size/same-command mission with modified coordinates is
       still detected because the full mission item representation is hashed.
    2. Change persistence: a mission mutation must persist across update cycles
       before it becomes a strong signal.
    3. Current-item continuity: unexpected jumps in the active mission index
       are scored separately from a legitimate mission completion/advance.
    4. Mission-size change detection.
    5. Command-sequence anomaly: unexpected current command IDs relative to the
       previous command are retained as contextual evidence.
    6. Airborne context weighting: mission mutations while armed/in mission
       mode receive stronger confidence than pre-arm edits.
*/
#include "MissionDetector.h"

#if AP_IDS_ENABLED

#include <AP_HAL/AP_HAL.h>
#include <AP_Math/AP_Math.h>
#include <string.h>

namespace {

constexpr uint32_t FNV_OFFSET = 2166136261UL;
constexpr uint32_t FNV_PRIME = 16777619UL;
constexpr uint16_t INDEX_JUMP = 2U;
constexpr float PERSISTENCE_STEP = 0.25f;
constexpr float PERSISTENCE_DECAY = 0.85f;

} // namespace

MissionDetector::MissionDetector()
{
    reset();
}

void MissionDetector::reset()
{
    _initialised = false;
    _baseline_hash = 0;
    _baseline_count = 0;
    _previous_index = 0;
    _previous_count = 0;
    _previous_command_id = 0;
    _change_persistence = 0.0f;
    _result = Result {
        AP_IDS::EVID_NONE,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0,
        0,
        0
    };
}

uint32_t MissionDetector::fnv1a_mix(uint32_t hash,
                                    const void *data,
                                    uint32_t len)
{
    const uint8_t *bytes = static_cast<const uint8_t *>(data);
    for (uint32_t i = 0; i < len; i++) {
        hash ^= bytes[i];
        hash *= FNV_PRIME;
    }
    return hash;
}

float MissionDetector::clamp01(float x)
{
    return constrain_float(x, 0.0f, 1.0f);
}

uint32_t MissionDetector::calculate_hash(const AP_Mission &mission) const
{
    uint32_t hash = FNV_OFFSET;
    const uint16_t count = mission.num_commands();
    hash = fnv1a_mix(hash, &count, sizeof(count));

    // item 0 is home, rewritten at arming: not part of the mission's integrity
    for (uint16_t index = 1; index < count; index++) {
        mavlink_mission_item_int_t item{};
        if (!mission.get_item(index, item)) {
            // Include failed-read state in the fingerprint. A storage fault
            // must not accidentally look identical to a valid mission.
            const uint8_t failure = 0xFF;
            hash = fnv1a_mix(hash, &failure, sizeof(failure));
            continue;
        }
        hash = fnv1a_mix(hash, &item, sizeof(item));
    }

    return hash;
}

float MissionDetector::update_change_persistence(bool changed)
{
    if (changed) {
        _change_persistence = clamp01(_change_persistence + PERSISTENCE_STEP);
    } else {
        _change_persistence *= PERSISTENCE_DECAY;
    }
    return _change_persistence;
}

MissionDetector::Result MissionDetector::update(const AP_Mission &mission,
                                                  bool armed,
                                                  bool mission_mode)
{
    Result result = _result;
    result.evidence = AP_IDS::EVID_NONE;
    result.confidence = 0.0f;
    result.mission_change_score = 0.0f;
    result.current_item_jump_score = 0.0f;
    result.command_sequence_score = 0.0f;
    result.flight_context_score = 0.0f;

    const uint16_t count = mission.num_commands();
    const uint16_t current_index = mission.get_current_nav_index();
    const uint16_t current_command_id = mission.get_current_nav_id();
    const uint32_t mission_hash = calculate_hash(mission);

    result.mission_hash = mission_hash;
    result.command_count = count;
    result.current_index = current_index;

    if (!_initialised) {
        _baseline_hash = mission_hash;
        _baseline_count = count;
        _previous_index = current_index;
        _previous_count = count;
        _previous_command_id = current_command_id;
        _initialised = true;
        return (_result = result);
    }

    if (!armed) {
        _baseline_hash = mission_hash;   // ground edits are legitimate; only armed changes count
    }
    const bool hash_changed = mission_hash != _baseline_hash;
    const bool count_changed = count != _previous_count;
    const int32_t index_delta = static_cast<int32_t>(current_index) -
                                static_cast<int32_t>(_previous_index);

    // An index reset/jump is suspicious only when it is not the ordinary
    // one-step progression. Completion/reset at index 0 is treated separately.
    if (index_delta > static_cast<int32_t>(INDEX_JUMP) || index_delta < -static_cast<int32_t>(INDEX_JUMP)) {
        if (current_index != 0U && mission.state() == AP_Mission::MISSION_RUNNING) {
            result.current_item_jump_score = 0.75f;
            result.evidence |= AP_IDS::EVID_CONTEXT_ANOMALY;
        }
    }

    if (count_changed) {
        result.mission_change_score = fmaxf(result.mission_change_score, 0.90f);
        result.evidence |= AP_IDS::EVID_INTEGRITY_ANOMALY;
    }

    if (hash_changed) {
        const float persistence = update_change_persistence(true);
        result.mission_change_score = fmaxf(result.mission_change_score,
                                             0.70f + 0.30f * persistence);
        result.evidence |= AP_IDS::EVID_INTEGRITY_ANOMALY;
    } else {
        update_change_persistence(false);
    }

    // If the currently executing command ID changes in a way that is not a
    // simple mission progression, retain it as context rather than declaring
    // an attack by command ID alone.
    if (current_command_id != _previous_command_id &&
        current_index == _previous_index &&
        current_index != 0U) {
        result.command_sequence_score = 0.65f;
        result.evidence |= AP_IDS::EVID_SEQUENCE_ANOMALY;
    }

    if ((armed && mission_mode) || (armed && hash_changed)) {
        result.flight_context_score = 0.85f;
        result.evidence |= AP_IDS::EVID_CONTEXT_ANOMALY;
    } else if (armed) {
        result.flight_context_score = 0.35f;
    }

    // First observed change establishes a candidate. Repeated confirmation is
    // provided by persistence and the shared AP_IDS state machine.
    result.confidence = clamp01(
        0.45f * result.mission_change_score +
        0.20f * result.current_item_jump_score +
        0.15f * result.command_sequence_score +
        0.20f * result.flight_context_score);

    _previous_index = current_index;
    _previous_count = count;
    _previous_command_id = current_command_id;

    _result = result;
    return _result;
}

#endif // AP_IDS_ENABLED
