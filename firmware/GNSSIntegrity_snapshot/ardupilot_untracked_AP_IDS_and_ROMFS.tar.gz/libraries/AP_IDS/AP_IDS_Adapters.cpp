/*
  PUSHPAK UAV IDS - ArduPilot adapters for the five detectors that
  AP_IDS::update() did not drive (DISC-003): MAVLink, Command, Parameter,
  RC link and Offboard.

  Defensive monitoring only. Nothing here alters a message, a command, a
  parameter write, a failsafe or a flight mode; the detectors only publish
  evidence through AP_IDS::publish().

  Feeding model
    * MAVLink, Command, Parameter and Offboard are event driven: every MAVLink
      packet the vehicle accepts is offered to handle_mavlink() from
      GCS_MAVLINK_Copter::packetReceived(). Per-packet results are folded into
      a per-window peak and published from update_adapters() (5 Hz), with a
      short hold so a state does not flicker between consecutive packets.
    * RC link is polled from update_adapters().

  Known limits (documented, not hidden)
    * MAVLink rx-rate scoring is disabled (rx_rate_hz = 0): no per-source rate
      measurement is made here.
    * MAVLink signing_expected is false: the adapter does not know whether a
      channel is meant to be signed.
    * Parameter changes are only seen when requested over MAVLink (PARAM_SET);
      changes from Lua or RC aux functions are not observed here.
    * Offboard tracking error is not supplied (left to offboard_confirm.lua),
      because distance-to-target is large during legitimate transit.
    * A setpoint sender is "expected" only if it is the configured GCS
      (MAV_GCS_SYSID); a companion computer on another SYSID is reported.
*/
#include "AP_IDS.h"

#if AP_IDS_ENABLED

#include "CommandDetector.h"
#include "MAVLinkDetector.h"
#include "OffboardDetector.h"
#include "ParameterDetector.h"
#include "RCDetector.h"

#include <AP_Arming/AP_Arming.h>
#include <AP_Mission/AP_Mission.h>
#include <AP_RSSI/AP_RSSI.h>
#include <AP_Vehicle/AP_Vehicle.h>
#include <GCS_MAVLink/GCS.h>
#include <RC_Channel/RC_Channel.h>
#include <string.h>

namespace {

constexpr uint8_t MAX_CHANNELS = 8;
constexpr uint8_t MAX_HB_SOURCES = 8;
constexpr uint32_t STATE_HOLD_MS = 3000;
constexpr uint32_t GCS_LOSS_MS = 3000;
constexpr uint32_t OFFBOARD_STALE_MS = 1500;
constexpr uint8_t COPTER_MODE_GUIDED = 4;   // AP_IDS is integrated with ArduCopter only

enum PeakIndex : uint8_t { P_MAVLINK = 0, P_COMMAND, P_PARAMETER, P_OFFBOARD, P_COUNT };

struct Peak {
    bool seen;
    float confidence;
    uint16_t evidence;
    float metric;
    uint8_t instance;
};

struct Hold {
    AP_IDS::State state;
    float confidence;
    uint16_t evidence;
    uint32_t until_ms;
};

struct HeartbeatSource {
    bool active;
    uint8_t sysid;
    uint8_t compid;
    uint32_t last_ms;
};

MAVLinkDetector mavlink_detector;
CommandDetector command_detector;
ParameterDetector parameter_detector;
RCDetector rc_detector;
OffboardDetector offboard_detector;

Peak peaks[P_COUNT];
Hold holds[P_COUNT + 1];   // + RC
HeartbeatSource hb_sources[MAX_HB_SOURCES];

uint16_t last_drop[MAX_CHANNELS];
uint8_t last_parse_error[MAX_CHANNELS];
bool channel_seen[MAX_CHANNELS];
uint32_t telemetry_drops_window;

bool offboard_active;
uint32_t offboard_last_ms;
float offboard_rate_hz;
uint8_t offboard_sysid;
uint8_t offboard_compid;

bool rc_ever_valid;

const char *const SENSITIVE_PREFIXES[] = {
    "ARMING_", "FENCE_", "FS_", "BATT_FS", "GPS", "SYSID", "MAV_GCS", "SERIAL", "BRD_SAFETY",
    "EK3_SRC", "SCR_", "RC_OPTIONS", "DISARM_DELAY", "RTL_", "WP_", "WPNAV_", "ATC_ANGLE_MAX",
    "ANGLE_MAX", "LOG_",
};

AP_IDS::State state_for(float confidence)
{
    if (confidence >= 0.75f) {
        return AP_IDS::State::CONFIRMED;
    }
    if (confidence >= 0.45f) {
        return AP_IDS::State::SUSPECTED;
    }
    return AP_IDS::State::CLEAR;
}

// Keep a raised state (with the confidence/evidence that raised it) for STATE_HOLD_MS so
// per-packet evidence does not flicker. Returns the hold to publish.
const Hold &held(uint8_t index, float confidence, uint16_t evidence, uint32_t now_ms)
{
    Hold &h = holds[index];
    const AP_IDS::State current = state_for(confidence);
    if (static_cast<uint8_t>(current) >= static_cast<uint8_t>(h.state) || now_ms > h.until_ms) {
        h.state = current;
        h.confidence = confidence;
        h.evidence = evidence;
        if (current != AP_IDS::State::CLEAR) {
            h.until_ms = now_ms + STATE_HOLD_MS;
        }
    }
    return h;
}

void take(Peak &p, float confidence, uint16_t evidence, float metric, uint8_t instance)
{
    if (!p.seen || confidence > p.confidence) {
        p.confidence = confidence;
        p.metric = metric;
        p.instance = instance;
    }
    p.evidence |= evidence;
    p.seen = true;
}

uint32_t name_hash(const char *s, size_t n)
{
    uint32_t h = 2166136261U;   // FNV-1a
    for (size_t i = 0; i < n && s[i] != '\0'; i++) {
        h ^= static_cast<uint8_t>(s[i]);
        h *= 16777619U;
    }
    return h;
}

bool is_sensitive(const char *name, size_t n)
{
    for (const char *prefix : SENSITIVE_PREFIXES) {
        const size_t len = strlen(prefix);
        if (len <= n && strncmp(name, prefix, len) == 0) {
            return true;
        }
    }
    return false;
}

uint16_t heartbeat_gap_ms(uint8_t sysid, uint8_t compid, uint32_t now_ms)
{
    HeartbeatSource *free_slot = nullptr;
    for (auto &s : hb_sources) {
        if (s.active && s.sysid == sysid && s.compid == compid) {
            const uint32_t gap = now_ms - s.last_ms;
            s.last_ms = now_ms;
            return static_cast<uint16_t>(MIN(gap, 65535U));
        }
        if (!s.active && free_slot == nullptr) {
            free_slot = &s;
        }
    }
    if (free_slot != nullptr) {
        *free_slot = HeartbeatSource{true, sysid, compid, now_ms};
    }
    return 0;
}

bool vehicle_airborne()
{
    const AP_Vehicle *v = AP::vehicle();
    return v != nullptr && v->get_likely_flying();
}

bool vehicle_guided()
{
    const AP_Vehicle *v = AP::vehicle();
    return v != nullptr && v->get_mode() == COPTER_MODE_GUIDED;
}

void observe_command(const mavlink_message_t &msg, uint16_t command, uint8_t target_sysid,
                     uint8_t target_compid, uint8_t confirmation, const float params[7], uint32_t now_ms)
{
    CommandDetector::Observation obs {};
    obs.time_ms = now_ms;
    obs.command_id = command;
    obs.source_sysid = msg.sysid;
    obs.source_compid = msg.compid;
    obs.target_sysid = target_sysid;
    obs.target_compid = target_compid;
    obs.confirmation = confirmation;
    obs.source_trusted = gcs().sysid_is_gcs(msg.sysid);
    obs.vehicle_armed = AP::arming().is_armed();
    obs.vehicle_airborne = vehicle_airborne();
    const AP_Mission *mission = AP::mission();
    obs.mission_running = mission != nullptr && mission->state() == AP_Mission::MISSION_RUNNING;
    obs.external_control_expected = vehicle_guided();
    memcpy(obs.params, params, sizeof(obs.params));
    const CommandDetector::Result r = command_detector.observe(obs);
    take(peaks[P_COMMAND], r.confidence, r.evidence, static_cast<float>(command), msg.sysid);
}

}  // namespace

void AP_IDS::handle_mavlink(uint8_t chan, const struct __mavlink_message &msg)
{
    if (chan >= MAX_CHANNELS) {
        return;
    }
    const uint32_t now_ms = AP_HAL::millis();

    // ---------------------------------------------------------------- transport
    uint16_t drop_delta = 0;
    uint16_t parse_error_delta = 0;
    const mavlink_status_t *status = mavlink_get_channel_status(static_cast<mavlink_channel_t>(chan));
    if (status != nullptr) {
        if (channel_seen[chan]) {
            drop_delta = static_cast<uint16_t>(status->packet_rx_drop_count - last_drop[chan]);
            parse_error_delta = static_cast<uint8_t>(status->parse_error - last_parse_error[chan]);
        }
        last_drop[chan] = status->packet_rx_drop_count;
        last_parse_error[chan] = status->parse_error;
        channel_seen[chan] = true;
    }
    telemetry_drops_window += drop_delta;

    const bool is_heartbeat = msg.msgid == MAVLINK_MSG_ID_HEARTBEAT;
    const bool is_command = msg.msgid == MAVLINK_MSG_ID_COMMAND_LONG || msg.msgid == MAVLINK_MSG_ID_COMMAND_INT;
    const bool is_signed = (msg.incompat_flags & MAVLINK_IFLAG_SIGNED) != 0;

    MAVLinkDetector::Observation mobs {};
    mobs.time_ms = now_ms;
    mobs.sysid = msg.sysid;
    mobs.compid = msg.compid;
    mobs.sequence = msg.seq;
    mobs.message_id = msg.msgid;
    mobs.is_heartbeat = is_heartbeat;
    mobs.is_command = is_command;
    mobs.is_signed = is_signed;
    mobs.signature_valid = is_signed;   // accepted frames have already passed signature checks
    mobs.signing_expected = false;
    mobs.packet_drop_delta = drop_delta;
    mobs.parse_error_delta = parse_error_delta;
    mobs.heartbeat_gap_ms = is_heartbeat ? heartbeat_gap_ms(msg.sysid, msg.compid, now_ms) : 0;
    mobs.rx_rate_hz = 0.0f;
    const MAVLinkDetector::Result mr = mavlink_detector.observe(mobs);
    take(peaks[P_MAVLINK], mr.confidence, mr.evidence, static_cast<float>(mr.active_sources), msg.sysid);

    // ---------------------------------------------------------------- commands
    switch (msg.msgid) {
    case MAVLINK_MSG_ID_COMMAND_LONG: {
        mavlink_command_long_t c;
        mavlink_msg_command_long_decode(&msg, &c);
        if (c.target_system != 0 && c.target_system != mavlink_system.sysid) {
            break;   // routed to another system
        }
        const float p[7] = {c.param1, c.param2, c.param3, c.param4, c.param5, c.param6, c.param7};
        observe_command(msg, c.command, c.target_system, c.target_component, c.confirmation, p, now_ms);
        break;
    }
    case MAVLINK_MSG_ID_COMMAND_INT: {
        mavlink_command_int_t c;
        mavlink_msg_command_int_decode(&msg, &c);
        if (c.target_system != 0 && c.target_system != mavlink_system.sysid) {
            break;
        }
        const float p[7] = {c.param1, c.param2, c.param3, c.param4,
                            static_cast<float>(c.x), static_cast<float>(c.y), c.z};
        observe_command(msg, c.command, c.target_system, c.target_component, 0, p, now_ms);
        break;
    }
    case MAVLINK_MSG_ID_SET_MODE: {
        mavlink_set_mode_t m;
        mavlink_msg_set_mode_decode(&msg, &m);
        if (m.target_system != mavlink_system.sysid) {
            break;
        }
        const float p[7] = {static_cast<float>(m.base_mode), static_cast<float>(m.custom_mode), 0, 0, 0, 0, 0};
        observe_command(msg, MAV_CMD_DO_SET_MODE, m.target_system, 0, 0, p, now_ms);
        break;
    }

    // ---------------------------------------------------------------- parameters
    case MAVLINK_MSG_ID_PARAM_SET: {
        mavlink_param_set_t ps;
        mavlink_msg_param_set_decode(&msg, &ps);
        if (ps.target_system != mavlink_system.sysid) {
            break;
        }
        const size_t n = strnlen(ps.param_id, sizeof(ps.param_id));
        const bool sensitive = is_sensitive(ps.param_id, n);
        const bool trusted = gcs().sysid_is_gcs(msg.sysid);
        // The detector has no notion of a trusted writer and, with < 3 samples per
        // parameter, scores any second write as a large deviation. Ordinary tuning of
        // non-sensitive parameters by the configured GCS is therefore not fed to it
        // (in SITL this raised SUSPECTED on every routine write while armed).
        if (trusted && !sensitive) {
            break;
        }
        ParameterDetector::Observation pobs {};
        pobs.parameter_id = name_hash(ps.param_id, n);
        pobs.value = ps.param_value;
        pobs.source_sysid = msg.sysid;
        pobs.source_compid = msg.compid;
        pobs.armed = AP::arming().is_armed();
        pobs.sensitive = sensitive;
        pobs.externally_requested = true;
        pobs.timestamp_ms = now_ms;
        const ParameterDetector::Result pr = parameter_detector.observe(pobs);
        take(peaks[P_PARAMETER], pr.confidence, pr.evidence, pr.value_change_score, msg.sysid);
        break;
    }

    // ---------------------------------------------------------------- offboard setpoints
    case MAVLINK_MSG_ID_SET_POSITION_TARGET_LOCAL_NED:
    case MAVLINK_MSG_ID_SET_POSITION_TARGET_GLOBAL_INT:
    case MAVLINK_MSG_ID_SET_ATTITUDE_TARGET: {
        if (offboard_active && now_ms > offboard_last_ms) {
            const float inst_hz = 1000.0f / static_cast<float>(now_ms - offboard_last_ms);
            offboard_rate_hz = offboard_rate_hz <= 0.0f ? inst_hz : 0.8f * offboard_rate_hz + 0.2f * inst_hz;
        }
        offboard_active = true;
        offboard_last_ms = now_ms;
        offboard_sysid = msg.sysid;
        offboard_compid = msg.compid;
        OffboardDetector::Observation oobs {};
        oobs.timestamp_ms = now_ms;
        oobs.source_sysid = msg.sysid;
        oobs.source_compid = msg.compid;
        oobs.setpoint_rate_hz = offboard_rate_hz;
        oobs.external_control_active = true;
        oobs.expected_source = gcs().sysid_is_gcs(msg.sysid);
        oobs.vehicle_armed = AP::arming().is_armed();
        oobs.vehicle_in_guided_mode = vehicle_guided();
        oobs.stream_valid = true;
        const OffboardDetector::Result orr = offboard_detector.update(oobs);
        take(peaks[P_OFFBOARD], orr.confidence, orr.evidence, offboard_rate_hz, msg.sysid);
        break;
    }
    default:
        break;
    }
}

void AP_IDS::update_adapters()
{
    const uint32_t now_ms = AP_HAL::millis();

    // ---------------------------------------------------------------- stale offboard stream
    if (offboard_active && now_ms - offboard_last_ms > OFFBOARD_STALE_MS) {
        OffboardDetector::Observation oobs {};
        oobs.timestamp_ms = now_ms;
        oobs.source_sysid = offboard_sysid;
        oobs.source_compid = offboard_compid;
        oobs.setpoint_rate_hz = 0.0f;
        oobs.external_control_active = vehicle_guided();
        oobs.expected_source = gcs().sysid_is_gcs(offboard_sysid);
        oobs.vehicle_armed = AP::arming().is_armed();
        oobs.vehicle_in_guided_mode = vehicle_guided();
        oobs.stream_valid = false;
        const OffboardDetector::Result orr = offboard_detector.update(oobs);
        take(peaks[P_OFFBOARD], orr.confidence, orr.evidence, 0.0f, offboard_sysid);
        offboard_active = false;
        offboard_rate_hz = 0.0f;
    }

    // ---------------------------------------------------------------- RC / telemetry link (polled)
    const bool rc_valid = rc().has_valid_input();
    rc_ever_valid = rc_ever_valid || rc_valid;
    const uint32_t gcs_last = gcs().sysid_mygcs_last_seen_time_ms();
    const bool gcs_seen = gcs_last != 0;
    const uint32_t gcs_gap = gcs_seen ? now_ms - gcs_last : 0;
    const bool telemetry_lost = gcs_seen && gcs_gap > GCS_LOSS_MS;
    // A vehicle flown without an RC transmitter never has valid RC input; only
    // treat RC as lost once it has been valid at least once.
    const bool rc_lost = rc_ever_valid && !rc_valid;

    float quality = rc_lost ? 0.0f : 1.0f;
    AP_RSSI *rssi = AP::rssi();
    if (rssi != nullptr && rssi->enabled()) {
        const float q = rssi->read_receiver_rssi();
        if (q >= 0.0f) {
            quality = q;
        }
    }
    RCDetector::Observation robs {};
    robs.time_ms = now_ms;
    robs.link_quality = quality;
    robs.rc_loss_ratio = rc_lost ? 1.0f : 0.0f;
    robs.telemetry_loss_ratio = telemetry_lost ? 1.0f : 0.0f;
    robs.heartbeat_gap_ms = static_cast<uint16_t>(MIN(gcs_gap, 65535U));
    robs.rc_frame_loss_delta = 0;
    robs.telemetry_drop_delta = static_cast<uint16_t>(MIN(telemetry_drops_window, 65535U));
    robs.rc_link_active = !rc_lost;
    robs.telemetry_link_active = !telemetry_lost;
    robs.failsafe_active = rc_ever_valid && rc().in_rc_failsafe();
    telemetry_drops_window = 0;
    const RCDetector::Result rr = rc_detector.observe(robs);
    const Hold &rh = held(P_COUNT, rr.confidence, rr.evidence, now_ms);
    publish(Detector::RC_LINK, rh.state, rh.evidence, rh.confidence, static_cast<float>(robs.heartbeat_gap_ms), 0);

    // ---------------------------------------------------------------- event-driven detectors
    static const Detector map[P_COUNT] = {Detector::MAVLINK, Detector::COMMAND, Detector::PARAMETER, Detector::OFFBOARD};
    for (uint8_t i = 0; i < P_COUNT; i++) {
        Peak &p = peaks[i];
        const Hold &h = held(i, p.seen ? p.confidence : 0.0f,
                             p.seen ? p.evidence : static_cast<uint16_t>(EVID_NONE), now_ms);
        publish(map[i], h.state, h.evidence, h.confidence, p.metric, p.instance);
        p = Peak{};
    }
}

#endif  // AP_IDS_ENABLED
