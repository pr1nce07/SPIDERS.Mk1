/*
  PUSHPAK UAV IDS - external/offboard control anomaly detector

  Normalized observation interface for GUIDED/offboard/companion-control
  streams. Read-only and intentionally independent of a particular transport.
*/
#pragma once

#include <stdint.h>

#include "AP_IDS.h"

#if AP_IDS_ENABLED

class OffboardDetector
{
public:
    struct Observation {
        uint32_t timestamp_ms;
        uint8_t source_sysid;
        uint8_t source_compid;
        float setpoint_rate_hz;
        float position_error_m;
        float velocity_error_ms;
        float attitude_error_rad;
        float commanded_speed_ms;
        float observed_speed_ms;
        bool external_control_active;
        bool expected_source;
        bool vehicle_armed;
        bool vehicle_in_guided_mode;
        bool stream_valid;
    };

    struct Result {
        uint16_t evidence;
        float confidence;
        float stale_stream_score;
        float rate_anomaly_score;
        float source_anomaly_score;
        float tracking_divergence_score;
        float context_score;
        float burst_score;
        uint8_t source_sysid;
        uint8_t source_compid;
    };

    OffboardDetector();
    void reset();
    Result update(const Observation &observation);

    const Result &result() const { return _result; }

private:
    static float clamp01(float x);
    static float absf(float x);

    bool _initialised;
    uint32_t _last_timestamp_ms;
    uint8_t _last_source_sysid;
    uint8_t _last_source_compid;
    float _last_setpoint_rate_hz;
    float _rate_ewma;
    float _rate_var;
    float _rate_cusum;
    float _tracking_ewma;
    float _tracking_var;
    float _tracking_cusum;
    uint8_t _burst_count;
    Result _result;
};

#endif // AP_IDS_ENABLED
