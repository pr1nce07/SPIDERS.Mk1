/*
  PUSHPAK UAV IDS - ArduPilot integration layer
  Target: ArduPilot 4.7.x / Pixhawk 6C

  Defensive monitoring only: this library observes autopilot state and
  publishes evidence. It does not change navigation, actuator output,
  arming, disarming, or flight termination state.
*/
#pragma once

#include <AP_HAL/AP_HAL.h>
#include <AP_Vehicle/AP_Vehicle_Type.h>
#include <stdint.h>

struct __mavlink_message;

// Only ArduCopter links libraries/AP_IDS (see ArduCopter/wscript). Other
// programs that compile the generated Lua bindings (tool/Replay, other
// vehicles) must see AP_IDS_ENABLED 0, or they reference AP_IDS symbols
// that are never linked. AP_IDS itself is built as a vehicle-independent
// library (no APM_BUILD_DIRECTORY), and only when Copter links it.
#ifndef AP_IDS_ENABLED
#ifdef APM_BUILD_DIRECTORY
#define AP_IDS_ENABLED APM_BUILD_COPTER_OR_HELI
#else
#define AP_IDS_ENABLED 1
#endif
#endif

#if AP_IDS_ENABLED

#include "AP_IDS_GNSSIntegrity.h"

class AP_IDS
{
public:
    enum class Detector : uint8_t {
        GPS = 0,
        MAVLINK,
        COMMAND,
        RC_LINK,
        IMU,
        MISSION,
        PARAMETER,
        OFFBOARD,
        COUNT
    };

    enum class State : uint8_t {
        CLEAR = 0,
        SUSPECTED,
        CONFIRMED
    };

    // Bit flags identify the evidence that contributed to an event. Keep this
    // fixed-width: the structure is carried between FC, Lua and GCS layers.
    enum EvidenceBits : uint16_t {
        EVID_NONE                    = 0,
        EVID_PERSISTENCE             = 1U << 0,
        EVID_ROBUST_DEVIATION        = 1U << 1,
        EVID_EWMA_CHANGE             = 1U << 2,
        EVID_CUSUM_CHANGE            = 1U << 3,
        EVID_CROSS_SENSOR            = 1U << 4,
        EVID_KINEMATIC_MISMATCH      = 1U << 5,
        EVID_QUALITY_MISMATCH        = 1U << 6,
        EVID_SOURCE_ANOMALY          = 1U << 7,
        EVID_SEQUENCE_ANOMALY        = 1U << 8,
        EVID_CONTEXT_ANOMALY         = 1U << 9,
        EVID_RATE_ANOMALY            = 1U << 10,
        EVID_INTEGRITY_ANOMALY       = 1U << 11,
        EVID_RESET_ANOMALY           = 1U << 12,
        EVID_BASELINE_NOT_READY      = 1U << 13,
        EVID_DEGRADED_SENSOR         = 1U << 14,
        EVID_EKF_INNOVATION          = 1U << 15,
    };

    struct Event {
        uint32_t time_ms;
        Detector detector;
        State state;
        uint16_t evidence;
        float confidence;
        float primary_metric;
        uint8_t source_instance;
        uint8_t reserved[3];
    };

    static constexpr uint8_t EVENT_RING_SIZE = 8;
    static constexpr float CONFIDENCE_MIN = 0.0f;
    static constexpr float CONFIDENCE_MAX = 1.0f;

    AP_IDS();

    AP_IDS(const AP_IDS&) = delete;
    AP_IDS& operator=(const AP_IDS&) = delete;

    static AP_IDS *get_singleton();

    void init();
    void update();

#if AP_IDS_GNSSINT_ENABLED
    AP_IDS_GNSSIntegrity gnss_integrity;   // passive IMU-propagated GNSS integrity engine
#endif

    // Every MAVLink packet the vehicle accepts (called from the vehicle's
    // packetReceived). Feeds the MAVLink, Command, Parameter and Offboard detectors.
    void handle_mavlink(uint8_t chan, const struct __mavlink_message &msg);

    void publish(Detector detector,
                 State state,
                 uint16_t evidence,
                 float confidence,
                 float primary_metric = 0.0f,
                 uint8_t source_instance = 0);

    State state(Detector detector) const;
    float confidence(Detector detector) const;
    uint16_t evidence(Detector detector) const;
    uint32_t last_update_ms(Detector detector) const;
    // Lua: local state, conf, evidence = ids:get_channel(i)  (i = Detector index 0..7; nil if invalid)
    bool get_channel(uint8_t detector, uint8_t &state_out, float &confidence_out, uint16_t &evidence_out) const;

    // No-argument Lua-facing accessors. These avoid exposing enum arguments to
    // the binding generator while keeping the scripting API compact.
    float gps_confidence() const;
    uint16_t gps_evidence() const;
    uint8_t gps_state() const;
    float mavlink_confidence() const;
    uint16_t mavlink_evidence() const;
    uint8_t mavlink_state() const;
    float command_confidence() const;
    uint16_t command_evidence() const;
    uint8_t command_state() const;
    float rc_confidence() const;
    uint16_t rc_evidence() const;
    uint8_t rc_state() const;
    float imu_confidence() const;
    uint16_t imu_evidence() const;
    float mission_confidence() const;
    uint16_t mission_evidence() const;
    uint8_t mission_state() const;
    float parameter_confidence() const;
    uint16_t parameter_evidence() const;
    uint8_t parameter_state() const;
    float offboard_confidence() const;
    uint16_t offboard_evidence() const;
    uint8_t offboard_state() const;
    // Global IDS event sequence. Lua uses this as the incident/report ID.
    uint32_t event_sequence() const { return _event_sequence; }

    // Called only after the Lua confirmation layer has independently
    // confirmed a detector event. Emits a MAVLink STATUSTEXT report.
    bool report_confirmed(const char *detector,
                          uint8_t level,
                          float confidence,
                          uint16_t evidence,
                          float primary_metric,
                          uint8_t source_instance,
                          uint32_t event_id);

    bool get_latest_event(Event &event) const;
    uint8_t event_count() const { return _event_count; }

private:
    struct ChannelState {
        State state;
        uint16_t evidence;
        float confidence;
        float primary_metric;
        uint32_t last_update_ms;
        uint8_t source_instance;
    };

    static float clamp01(float value);
    void update_adapters();   // RC poll + publish event-driven detectors (AP_IDS_Adapters.cpp)

    ChannelState _channels[static_cast<uint8_t>(Detector::COUNT)];
    Event _events[EVENT_RING_SIZE];
    uint8_t _event_head;
    uint8_t _event_count;
    uint32_t _event_sequence;
    bool _initialised;

    static AP_IDS *_singleton;
};

namespace AP {
AP_IDS &ids();
}

#endif // AP_IDS_ENABLED
