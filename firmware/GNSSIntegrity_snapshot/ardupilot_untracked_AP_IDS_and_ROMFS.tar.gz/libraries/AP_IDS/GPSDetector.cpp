/*
  PUSHPAK UAV IDS - GPS / INS anomaly detector implementation

  Detection methods:
    1. Rolling median/MAD robust deviation for abrupt or non-Gaussian changes.
    2. EWMA change detector for low-rate, stealthy drift.
    3. One-sided CUSUM for cumulative small residual changes.
    4. EKF GPS innovation/variance cross-check.
    5. GPS-vs-INS velocity consistency check.
    6. Cross-receiver position disagreement when redundant GPS data exist.
    7. GNSS-quality consistency: large residual despite apparently good fix quality.
    8. Estimator-reset awareness to suppress reset-induced false positives.
    9. Persistence/hysteresis before CONFIRMED state.

  This file does not command the vehicle or alter navigation state.
*/
#include "GPSDetector.h"

#if AP_IDS_ENABLED

#include <AP_HAL/AP_HAL.h>
#include <AP_Math/AP_Math.h>
#include <math.h>

namespace {

constexpr float ROBUST_Z_SUSPECT = 3.5f;
constexpr float ROBUST_Z_CONFIRM = 6.0f;
constexpr float EWMA_ALPHA = 0.12f;
constexpr float EWMA_FLOOR_M = 1.0f;
constexpr float CUSUM_ALLOWANCE_M = 0.25f;
constexpr float CUSUM_THRESHOLD_M = 4.0f;
constexpr float CUSUM_SCALE_M = 8.0f;
constexpr float VELOCITY_MISMATCH_SUSPECT_MPS = 2.0f;
constexpr float VELOCITY_MISMATCH_CONFIRM_MPS = 5.0f;
constexpr float CROSS_GPS_SUSPECT_M = 8.0f;
constexpr float CROSS_GPS_CONFIRM_M = 25.0f;
constexpr float POSITION_RESIDUAL_SUSPECT_M = 8.0f;
constexpr float POSITION_RESIDUAL_CONFIRM_M = 25.0f;
constexpr float EKF_INNOV_SUSPECT_M = 3.0f;
constexpr float EKF_INNOV_CONFIRM_M = 10.0f;
constexpr uint8_t CONFIRM_PERSISTENCE = 5;
constexpr uint8_t CLEAR_PERSISTENCE = 0;
constexpr uint32_t RESET_GRACE_MS = 1500;

} // namespace

GPSDetector::GPSDetector()
{
    reset();
}

void GPSDetector::reset()
{
    for (auto &track : _tracks) {
        track = Track {};
    }
    _result = Result {
        false,
        AP_IDS::EVID_NONE,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0
    };
}

float GPSDetector::magnitude2(const Vector2f &v)
{
    return sqrtf(v.x * v.x + v.y * v.y);
}

float GPSDetector::magnitude3(const Vector3f &v)
{
    return sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
}

float GPSDetector::clamp01(float x)
{
    return constrain_float(x, 0.0f, 1.0f);
}

float GPSDetector::median(float *values, uint8_t count)
{
    if (count == 0) {
        return 0.0f;
    }

    // Tiny fixed-size insertion sort: no heap allocation and predictable cost.
    for (uint8_t i = 1; i < count; i++) {
        const float key = values[i];
        uint8_t j = i;
        while (j > 0 && values[j - 1] > key) {
            values[j] = values[j - 1];
            --j;
        }
        values[j] = key;
    }

    if ((count & 1U) != 0U) {
        return values[count / 2U];
    }
    return 0.5f * (values[(count / 2U) - 1U] + values[count / 2U]);
}

void GPSDetector::push_history(Track &track, float value)
{
    track.residual_history[track.history_head] = value;
    track.history_head = static_cast<uint8_t>(
        (track.history_head + 1U) % GPS_HISTORY_SIZE);
    if (track.history_count < GPS_HISTORY_SIZE) {
        track.history_count++;
    }
}

float GPSDetector::robust_zscore(float sample, const Track &track)
{
    if (track.history_count < 6U) {
        return 0.0f;
    }

    float values[GPS_HISTORY_SIZE];
    float deviations[GPS_HISTORY_SIZE];
    for (uint8_t i = 0; i < track.history_count; i++) {
        values[i] = track.residual_history[i];
    }

    const float med = median(values, track.history_count);
    for (uint8_t i = 0; i < track.history_count; i++) {
        deviations[i] = fabsf(track.residual_history[i] - med);
    }
    const float mad = median(deviations, track.history_count);

    // 1.4826 converts MAD to a Gaussian-equivalent sigma. The additive
    // floor prevents false huge z-scores during a near-zero residual baseline.
    const float robust_sigma = fmaxf(1.4826f * mad, 0.75f);
    return fabsf(sample - med) / robust_sigma;
}

float GPSDetector::ewma_score(Track &track, float sample)
{
    if (!track.initialised) {
        track.ewma = sample;
        track.ewma_var = 0.0f;
        track.initialised = true;
        return 0.0f;
    }

    const float previous = track.ewma;
    const float error = sample - previous;
    track.ewma = (1.0f - EWMA_ALPHA) * track.ewma + EWMA_ALPHA * sample;
    track.ewma_var = (1.0f - EWMA_ALPHA) *
                     (track.ewma_var + EWMA_ALPHA * error * error);

    const float sigma = sqrtf(fmaxf(track.ewma_var, 0.0f)) + EWMA_FLOOR_M;
    return clamp01(fabsf(error) / (4.0f * sigma));
}

float GPSDetector::cusum_score(Track &track, float sample)
{
    if (!track.initialised) {
        return 0.0f;
    }

    const float baseline = track.ewma;
    const float delta = sample - baseline - CUSUM_ALLOWANCE_M;
    track.cusum_pos = fmaxf(0.0f, track.cusum_pos + delta);

    // Residuals are magnitudes, so negative drift is not itself suspicious.
    // Keep the negative accumulator for symmetry/future extensions.
    const float negative_delta = baseline - sample - CUSUM_ALLOWANCE_M;
    track.cusum_neg = fmaxf(0.0f, track.cusum_neg + negative_delta);

    // A single large outlier should not dominate forever.
    if (track.cusum_pos > 2.0f * CUSUM_THRESHOLD_M) {
        track.cusum_pos = 2.0f * CUSUM_THRESHOLD_M;
    }

    const float excursion = fmaxf(track.cusum_pos, track.cusum_neg);
    return clamp01((excursion - CUSUM_THRESHOLD_M) / CUSUM_SCALE_M);
}

float GPSDetector::position_consistency(const AP_GPS &gps,
                                         const AP_AHRS &ahrs,
                                         uint8_t instance,
                                         float &residual_m)
{
    Location ekf_location;
    if (!ahrs.get_location(ekf_location)) {
        residual_m = 0.0f;
        return 0.0f;
    }

    if (gps.status(instance) < AP_GPS::GPS_OK_FIX_3D) {
        residual_m = 0.0f;
        return 0.0f;
    }

    residual_m = gps.location(instance).get_distance(ekf_location);
    return clamp01(residual_m / POSITION_RESIDUAL_CONFIRM_M);
}

float GPSDetector::velocity_consistency(const AP_GPS &gps,
                                         const AP_AHRS &ahrs,
                                         uint8_t instance,
                                         float &residual_mps)
{
    Vector3f ekf_velocity;
    if (!ahrs.get_velocity_NED(ekf_velocity)) {
        residual_mps = 0.0f;
        return 0.0f;
    }

    if (gps.status(instance) < AP_GPS::GPS_OK_FIX_3D) {
        residual_mps = 0.0f;
        return 0.0f;
    }

    const Vector3f &gps_velocity = gps.velocity(instance);
    residual_mps = magnitude3(gps_velocity - ekf_velocity);
    return clamp01(residual_mps / VELOCITY_MISMATCH_CONFIRM_MPS);
}

float GPSDetector::cross_receiver_consistency(const AP_GPS &gps,
                                               uint8_t primary,
                                               float &cross_residual_m)
{
    cross_residual_m = 0.0f;
    if (gps.num_sensors() < 2U) {
        return 0.0f;
    }

    const Location &primary_location = gps.location(primary);
    float maximum_residual = 0.0f;

    for (uint8_t instance = 0; instance < gps.num_sensors(); instance++) {
        if (instance == primary) {
            continue;
        }
        if (gps.status(instance) < AP_GPS::GPS_OK_FIX_3D) {
            continue;
        }
        maximum_residual = fmaxf(
            maximum_residual,
            static_cast<float>(primary_location.get_distance(gps.location(instance))));
    }

    cross_residual_m = maximum_residual;
    return clamp01(cross_residual_m / CROSS_GPS_CONFIRM_M);
}

float GPSDetector::quality_consistency(const AP_GPS &gps, uint8_t instance)
{
    if (gps.status(instance) < AP_GPS::GPS_OK_FIX_3D) {
        return 0.0f;
    }

    float hacc = 0.0f;
    const bool hacc_valid = gps.horizontal_accuracy(instance, hacc);
    const float hdop = static_cast<float>(gps.get_hdop(instance)) * 0.01f;
    const uint8_t sats = gps.num_sats(instance);

    // This indicator is intentionally positive when reported receiver quality
    // remains strong. A bad-quality GPS sample is treated primarily as a
    // receiver/link problem, not as evidence of spoofing.
    const float sat_quality = clamp01((static_cast<float>(sats) - 6.0f) / 8.0f);
    const float hdop_quality = clamp01((2.5f - hdop) / 1.5f);
    const float hacc_quality = hacc_valid ? clamp01((8.0f - hacc) / 6.0f) : 0.5f;
    return (sat_quality + hdop_quality + hacc_quality) / 3.0f;
}

float GPSDetector::reset_artifact_penalty(const AP_AHRS &ahrs)
{
    const uint32_t now_ms = AP_HAL::millis();
    Vector2f pos_reset;
    Vector2f vel_reset;
    float hgt_reset = 0.0f;

    // 4.7.1: N/E reset getters return Vector2f and are not const-qualified
    AP_AHRS &ahrs_rw = const_cast<AP_AHRS &>(ahrs);
    const uint32_t pos_t = ahrs_rw.getLastPosNorthEastReset(pos_reset);
    const uint32_t vel_t = ahrs_rw.getLastVelNorthEastReset(vel_reset);
    const uint32_t hgt_t = ahrs_rw.getLastPosDownReset(hgt_reset);

    float penalty = 0.0f;
    if (pos_t != 0U && (now_ms - pos_t) <= RESET_GRACE_MS) {
        penalty = fmaxf(penalty, 1.0f);
    }
    if (vel_t != 0U && (now_ms - vel_t) <= RESET_GRACE_MS) {
        penalty = fmaxf(penalty, 0.75f);
    }
    if (hgt_t != 0U && (now_ms - hgt_t) <= RESET_GRACE_MS) {
        penalty = fmaxf(penalty, 0.75f);
    }
    return penalty;
}

GPSDetector::Result GPSDetector::update(const AP_GPS &gps, const AP_AHRS &ahrs)
{
    Result result = _result;
    result.valid = false;
    result.evidence = AP_IDS::EVID_NONE;
    result.confidence = 0.0f;
    result.position_residual_m = 0.0f;
    result.velocity_residual_mps = 0.0f;
    result.cross_gps_residual_m = 0.0f;
    result.robust_z = 0.0f;
    result.cusum = 0.0f;

    const uint8_t instance = gps.primary_sensor();
    if (instance >= GPS_MAX_TRACKED ||
        instance >= gps.num_sensors() ||
        gps.status(instance) < AP_GPS::GPS_OK_FIX_3D) {
        _result = result;
        return _result;
    }

    result.valid = true;
    Track &track = _tracks[instance];

    float position_score = position_consistency(
        gps, ahrs, instance, result.position_residual_m);
    float velocity_score = velocity_consistency(
        gps, ahrs, instance, result.velocity_residual_mps);
    float cross_score = cross_receiver_consistency(
        gps, instance, result.cross_gps_residual_m);
    const float quality_score = quality_consistency(gps, instance);
    const float reset_penalty = reset_artifact_penalty(ahrs);

    // Feed the position residual into three independent temporal detectors.
    result.robust_z = robust_zscore(result.position_residual_m, track);
    const float ewma = ewma_score(track, result.position_residual_m);
    result.cusum = cusum_score(track, result.position_residual_m);
    push_history(track, result.position_residual_m);
    track.previous_residual = result.position_residual_m;
    track.previous_ms = AP_HAL::millis();

    Vector3f vel_innov;
    Vector3f pos_innov;  // 4.7.1 get_innovations() signature
    Vector3f mag_innov;
    float tas_innov = 0.0f;
    float yaw_innov = 0.0f;
    float vel_var = 0.0f;
    float pos_var = 0.0f;
    float hgt_var = 0.0f;
    Vector3f mag_var;
    float tas_var = 0.0f;
    float ekf_innovation_score = 0.0f;

    if (ahrs.get_innovations(vel_innov, pos_innov, mag_innov, tas_innov, yaw_innov)) {
        const float innov_norm = magnitude2(Vector2f(pos_innov.x, pos_innov.y));
        if (ahrs.get_variances(vel_var, pos_var, hgt_var, mag_var, tas_var)) {
            // A high raw innovation is stronger evidence when EKF normalized
            // variance is not already saturated at the acceptance boundary.
            const float variance_weight = 1.0f - 0.65f * clamp01(pos_var);
            ekf_innovation_score = clamp01(innov_norm / EKF_INNOV_CONFIRM_M) * variance_weight;
        } else {
            ekf_innovation_score = clamp01(innov_norm / EKF_INNOV_CONFIRM_M);
        }
    }

    // Report evidence bits before applying reset suppression.
    if (track.history_count < 6U) {
        result.evidence |= AP_IDS::EVID_BASELINE_NOT_READY;
    } else {
        result.evidence |= AP_IDS::EVID_ROBUST_DEVIATION;
    }
    if (ewma > 0.10f) {
        result.evidence |= AP_IDS::EVID_EWMA_CHANGE;
    }
    if (result.cusum > 0.05f) {
        result.evidence |= AP_IDS::EVID_CUSUM_CHANGE;
    }
    if (cross_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_CROSS_SENSOR;
    }
    if (velocity_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_KINEMATIC_MISMATCH;
    }
    const float quality_mismatch_score = quality_score *
        clamp01(result.position_residual_m / POSITION_RESIDUAL_SUSPECT_M);
    if (quality_mismatch_score > 0.50f) {
        result.evidence |= AP_IDS::EVID_QUALITY_MISMATCH;
    }
    if (ekf_innovation_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_EKF_INNOVATION;
    }
    if (reset_penalty > 0.0f) {
        result.evidence |= AP_IDS::EVID_RESET_ANOMALY;
    }

    // A spoofing candidate is strongest when the apparent navigation source,
    // receiver metrics, and inertial estimate disagree simultaneously. This is
    // weighted evidence fusion rather than a single hard threshold.
    const float robust_score = clamp01(result.robust_z / ROBUST_Z_CONFIRM);
    const float position_score_robust = fmaxf(
        position_score,
        result.robust_z >= ROBUST_Z_SUSPECT ? 0.45f : 0.0f);

    float confidence =
        0.18f * position_score_robust +
        0.12f * robust_score +
        0.13f * ewma +
        0.15f * result.cusum +
        0.15f * velocity_score +
        0.13f * cross_score +
        0.07f * quality_mismatch_score +
        0.07f * ekf_innovation_score;

    // Estimator resets are a known benign explanation for short-lived
    // position/velocity residuals. Suppress but do not erase the evidence.
    confidence *= (1.0f - 0.75f * reset_penalty);

    // Persistence/hysteresis: a stealthy attack that stays just above the
    // decision boundary accumulates confidence, while a transient outlier
    // decays instead of immediately becoming a confirmed event.
    const bool suspicious =
        confidence >= 0.55f ||
        result.robust_z >= ROBUST_Z_CONFIRM ||
        result.position_residual_m >= POSITION_RESIDUAL_CONFIRM_M ||
        result.velocity_residual_mps >= VELOCITY_MISMATCH_CONFIRM_MPS ||
        result.cross_gps_residual_m >= CROSS_GPS_CONFIRM_M;

    if (suspicious) {
        if (track.persistence < CONFIRM_PERSISTENCE) {
            track.persistence++;
        }
        result.evidence |= AP_IDS::EVID_PERSISTENCE;
    } else if (confidence < 0.35f && track.persistence > CLEAR_PERSISTENCE) {
        track.persistence--;
    }

    result.persistence = track.persistence;
    result.confidence = clamp01(confidence);

    if (track.persistence >= CONFIRM_PERSISTENCE) {
        result.confidence = fmaxf(result.confidence, 0.85f);
    }

    if (position_score > 0.40f ||
        velocity_score > 0.40f ||
        cross_score > 0.40f ||
        ekf_innovation_score > 0.40f) {
        result.evidence |= AP_IDS::EVID_KINEMATIC_MISMATCH;
    }
    if (ekf_innovation_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_EKF_INNOVATION;
    }

    _result = result;
    return _result;
}

#endif // AP_IDS_ENABLED
