/*
  PUSHPAK UAV IDS - MAVLink transport / source anomaly detector

  Detection methods:
    1. Sequence continuity analysis with duplicate and out-of-order detection.
    2. Source-profile novelty detection for unexpected SYSID/COMPID pairs.
    3. Heartbeat/inter-arrival EWMA and variance tracking.
    4. One-sided timing CUSUM for low-and-slow link degradation.
    5. Receive-rate EWMA/CUSUM for gradual DoS/degradation detection.
    6. Packet-drop and parser-error evidence fusion.
    7. Context-aware signing checks: unsigned traffic only contributes strongly
       when the channel explicitly requires signing; invalid signatures are
       treated as stronger evidence.
    8. Bounded persistence through the shared AP_IDS layer.

  This detector does not transmit, inject, modify, or replay MAVLink traffic.
*/
#include "MAVLinkDetector.h"

#if AP_IDS_ENABLED

#include <AP_Math/AP_Math.h>
#include <math.h>

namespace {

constexpr uint32_t MAX_PROFILE_GAP_MS = 10000;
constexpr float TIMING_CHANGE_FLOOR_MS = 25.0f;
constexpr float TIMING_CUSUM_K_MS = 25.0f;
constexpr float TIMING_CUSUM_H_MS = 250.0f;
constexpr float RATE_CUSUM_K_HZ = 0.15f;
constexpr float RATE_CUSUM_H_HZ = 0.75f;
constexpr float RATE_CHANGE_MIN_HZ = 0.5f;
constexpr float SOURCE_NOVELTY_SCORE = 0.45f;
constexpr float INVALID_SIGNATURE_SCORE = 1.0f;
constexpr float REQUIRED_SIGNING_UNSIGNED_SCORE = 0.65f;

} // namespace

MAVLinkDetector::MAVLinkDetector()
{
    reset();
}

void MAVLinkDetector::reset()
{
    for (auto &source : _sources) {
        source = SourceProfile {};
    }
    _result = Result {AP_IDS::EVID_NONE, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0};
}

float MAVLinkDetector::clamp01(float x)
{
    return constrain_float(x, 0.0f, 1.0f);
}

uint8_t MAVLinkDetector::sequence_delta(uint8_t previous, uint8_t current)
{
    return static_cast<uint8_t>(current - previous);
}

MAVLinkDetector::SourceProfile *MAVLinkDetector::find_or_create_source(
    uint8_t sysid,
    uint8_t compid,
    uint32_t now_ms,
    bool &new_source)
{
    new_source = false;

    for (auto &source : _sources) {
        if (source.active && source.sysid == sysid && source.compid == compid) {
            return &source;
        }
    }

    SourceProfile *candidate = nullptr;
    for (auto &source : _sources) {
        if (!source.active) {
            candidate = &source;
            break;
        }
        if (candidate == nullptr || source.last_seen_ms < candidate->last_seen_ms) {
            candidate = &source;
        }
    }

    if (candidate == nullptr) {
        return nullptr;
    }

    *candidate = SourceProfile {
        true,
        sysid,
        compid,
        0,
        now_ms,
        0,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0,
        0
    };
    new_source = true;
    return candidate;
}

float MAVLinkDetector::update_timing(SourceProfile &profile, uint32_t now_ms)
{
    if (profile.last_seen_ms == 0U || (now_ms - profile.last_seen_ms) > MAX_PROFILE_GAP_MS) {
        profile.last_seen_ms = now_ms;
        profile.interarrival_ewma_ms = 0.0f;
        profile.interarrival_var_ms2 = 0.0f;
        profile.timing_cusum = 0.0f;
        return 0.0f;
    }

    const float dt = static_cast<float>(now_ms - profile.last_seen_ms);
    const float alpha = 0.12f;
    const float expected = profile.interarrival_ewma_ms;

    if (expected <= 0.0f) {
        profile.interarrival_ewma_ms = dt;
        profile.interarrival_var_ms2 = 0.0f;
        profile.last_seen_ms = now_ms;
        return 0.0f;
    }

    const float error = dt - expected;
    profile.interarrival_ewma_ms = (1.0f - alpha) * expected + alpha * dt;
    profile.interarrival_var_ms2 = (1.0f - alpha) *
                                   (profile.interarrival_var_ms2 + alpha * error * error);
    profile.last_seen_ms = now_ms;

    const float sigma = sqrtf(fmaxf(profile.interarrival_var_ms2, 0.0f)) + TIMING_CHANGE_FLOOR_MS;
    const float z = fabsf(error) / (3.0f * sigma);

    // One-sided accumulation of a growing delay. This catches low-rate or
    // intermittent degradation which may not cross a hard heartbeat timeout.
    const float delta = dt - expected - TIMING_CUSUM_K_MS;
    profile.timing_cusum = fmaxf(0.0f, profile.timing_cusum + delta);
    profile.timing_cusum = fminf(profile.timing_cusum, 2.0f * TIMING_CUSUM_H_MS);

    const float cusum = clamp01(
        (profile.timing_cusum - TIMING_CUSUM_H_MS) / TIMING_CUSUM_H_MS);
    return fmaxf(clamp01(z), cusum);
}

float MAVLinkDetector::update_rate(SourceProfile &profile, float rx_rate_hz)
{
    if (rx_rate_hz <= 0.0f) {
        return 0.0f;
    }

    constexpr float alpha = 0.08f;
    if (profile.rate_ewma_hz <= 0.0f) {
        profile.rate_ewma_hz = rx_rate_hz;
        profile.rate_cusum = 0.0f;
        return 0.0f;
    }

    const float baseline = profile.rate_ewma_hz;
    const float error = rx_rate_hz - baseline;
    profile.rate_ewma_hz = (1.0f - alpha) * baseline + alpha * rx_rate_hz;

    // Detect sustained loss of received traffic. Positive excursions are not
    // treated as attacks by this transport detector; command-rate anomalies
    // are handled by the command detector.
    const float deficit = baseline - rx_rate_hz - RATE_CUSUM_K_HZ;
    profile.rate_cusum = fmaxf(0.0f, profile.rate_cusum + deficit);
    profile.rate_cusum = fminf(profile.rate_cusum, 2.0f * RATE_CUSUM_H_HZ);

    const float relative_change =
        fabsf(error) / fmaxf(fabsf(baseline), RATE_CHANGE_MIN_HZ);
    const float gradual_loss = clamp01(relative_change / 0.60f);
    const float cusum = clamp01(
        (profile.rate_cusum - RATE_CUSUM_H_HZ) / RATE_CUSUM_H_HZ);
    return fmaxf(gradual_loss, cusum);
}

MAVLinkDetector::Result MAVLinkDetector::observe(const Observation &obs)
{
    Result result = _result;
    result.evidence = AP_IDS::EVID_NONE;
    result.confidence = 0.0f;
    result.sequence_score = 0.0f;
    result.timing_score = 0.0f;
    result.source_score = 0.0f;
    result.signing_score = 0.0f;
    result.rate_score = 0.0f;

    bool new_source = false;
    SourceProfile *source = find_or_create_source(
        obs.sysid, obs.compid, obs.time_ms, new_source);

    if (source == nullptr) {
        result.source_score = SOURCE_NOVELTY_SCORE;
        result.active_sources = MAX_SOURCES;
        result.confidence = SOURCE_NOVELTY_SCORE;
        result.evidence = AP_IDS::EVID_SOURCE_ANOMALY;
        _result = result;
        return _result;
    }

    uint8_t delta = 1;
    if (!new_source) {
        delta = sequence_delta(source->last_sequence, obs.sequence);
        if (delta == 0U) {
            source->duplicate_seq_count++;
            result.sequence_score = 1.0f;
        } else if (delta > 1U && delta < 128U) {
            // Forward gap: packets were likely lost. The larger the gap, the
            // stronger the transport anomaly, capped at 64 packets.
            const uint8_t gap = static_cast<uint8_t>(delta - 1U);
            result.sequence_score = clamp01(static_cast<float>(gap) / 16.0f);
        } else if (delta >= 128U) {
            // A large backwards jump is consistent with out-of-order or
            // replay-like sequence reuse; treat it separately from loss.
            source->out_of_order_count++;
            result.sequence_score = 1.0f;
        }
    }
    source->last_sequence = obs.sequence;
    source->last_seen_ms = obs.time_ms;

    result.timing_score = update_timing(*source, obs.time_ms);
    result.rate_score = update_rate(*source, obs.rx_rate_hz);

    if (new_source) {
        result.source_score = SOURCE_NOVELTY_SCORE;
        result.evidence |= AP_IDS::EVID_SOURCE_ANOMALY;
    }

    if (result.sequence_score > 0.20f || obs.packet_drop_delta > 0U) {
        result.evidence |= AP_IDS::EVID_SEQUENCE_ANOMALY;
    }
    if (result.timing_score > 0.20f || obs.heartbeat_gap_ms > 2000U) {
        result.evidence |= AP_IDS::EVID_RATE_ANOMALY;
    }
    if (obs.packet_drop_delta > 0U || obs.parse_error_delta > 0U) {
        result.evidence |= AP_IDS::EVID_RATE_ANOMALY;
    }

    if (obs.signing_expected) {
        if (!obs.is_signed) {
            result.signing_score = REQUIRED_SIGNING_UNSIGNED_SCORE;
        } else if (!obs.signature_valid) {
            result.signing_score = INVALID_SIGNATURE_SCORE;
        }
        if (result.signing_score > 0.20f) {
            result.evidence |= AP_IDS::EVID_INTEGRITY_ANOMALY;
        }
    }

    if (obs.is_heartbeat && obs.heartbeat_gap_ms >= 2500U) {
        result.timing_score = fmaxf(result.timing_score,
                                    clamp01(static_cast<float>(obs.heartbeat_gap_ms - 2000U) / 4000.0f));
    }

    // Transport-focused evidence fusion. A new source alone does not confirm
    // compromise; source novelty becomes much stronger when sequence/timing or
    // integrity anomalies occur at the same time.
    float confidence =
        0.24f * result.sequence_score +
        0.22f * result.timing_score +
        0.18f * result.source_score +
        0.16f * result.signing_score +
        0.20f * result.rate_score;

    const uint16_t transport_faults = static_cast<uint16_t>(
        (obs.packet_drop_delta > 0U ? 1U : 0U) +
        (obs.parse_error_delta > 0U ? 1U : 0U));
    if (transport_faults > 0U) {
        confidence = fmaxf(
            confidence,
            clamp01(0.25f + 0.10f * static_cast<float>(transport_faults)));
    }

    // Source novelty is deliberately capped: legitimate companion devices can
    // appear at runtime. Confirmation requires additional independent evidence.
    if (new_source &&
        result.sequence_score < 0.20f &&
        result.timing_score < 0.20f &&
        result.signing_score < 0.20f) {
        confidence = fminf(confidence, 0.49f);
    }

    result.active_sources = 0;
    for (const auto &profile : _sources) {
        if (profile.active) {
            result.active_sources++;
        }
    }

    result.confidence = clamp01(confidence);
    _result = result;
    return _result;
}

#endif // AP_IDS_ENABLED
