/*
  PUSHPAK UAV IDS - redundant IMU consistency detector

  Uses the Pixhawk 6C's redundant inertial measurements to identify sensor
  divergence, gradual bias injection, transient faults and unexpected sensor
  health/selection changes. Read-only.
*/
#pragma once

#include <AP_InertialSensor/AP_InertialSensor.h>
#include <stdint.h>

#include "AP_IDS.h"

#if AP_IDS_ENABLED

class IMUDetector
{
public:
    static constexpr uint8_t MAX_IMUS = 3;
    static constexpr uint8_t MAX_PAIRS = 3;

    struct Result {
        uint16_t evidence;
        float confidence;
        float accel_divergence;
        float gyro_divergence;
        float consensus_score;
        float bias_drift_score;
        float health_score;
        float selection_change_score;
        uint8_t accel_outlier;
        uint8_t gyro_outlier;
    };

    IMUDetector();
    void reset();
    Result update(const AP_InertialSensor &ins);

    const Result &result() const { return _result; }

private:
    struct PairTrack {
        bool initialised;
        float accel_ewma;
        float gyro_ewma;
        float accel_var;
        float gyro_var;
        float accel_cusum;
        float gyro_cusum;
    };

    static float clamp01(float x);
    static float magnitude3(const Vector3f &v);

    float pair_score(PairTrack &track,
                     float accel_residual,
                     float gyro_residual);

    PairTrack _pairs[MAX_PAIRS];
    uint8_t _previous_primary_accel;
    uint8_t _previous_primary_gyro;
    bool _selection_initialised;
    Result _result;
};

#endif // AP_IDS_ENABLED
