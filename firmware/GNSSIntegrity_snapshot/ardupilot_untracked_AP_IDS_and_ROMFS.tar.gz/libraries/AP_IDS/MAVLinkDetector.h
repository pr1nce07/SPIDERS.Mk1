/*
  PUSHPAK UAV IDS - MAVLink transport / source anomaly detector

  Defensive monitoring of telemetry metadata. Payload-specific command
  inspection belongs in CommandDetector; this layer focuses on transport,
  source identity, sequencing and timing anomalies.
*/
#pragma once

#include <stdint.h>

#include "AP_IDS.h"

#if AP_IDS_ENABLED

class MAVLinkDetector
{
public:
    static constexpr uint8_t MAX_SOURCES = 8;

    struct Observation {
        uint32_t time_ms;
        uint8_t sysid;
        uint8_t compid;
        uint8_t sequence;
        uint32_t message_id;
        bool is_heartbeat;
        bool is_command;
        bool is_signed;
        bool signature_valid;
        bool signing_expected;
        uint16_t packet_drop_delta;
        uint16_t parse_error_delta;
        uint16_t heartbeat_gap_ms;
        float rx_rate_hz;
    };

    struct Result {
        uint16_t evidence;
        float confidence;
        float sequence_score;
        float timing_score;
        float source_score;
        float signing_score;
        float rate_score;
        uint8_t active_sources;
    };

    MAVLinkDetector();

    void reset();
    Result observe(const Observation &obs);

    const Result &result() const { return _result; }

private:
    struct SourceProfile {
        bool active;
        uint8_t sysid;
        uint8_t compid;
        uint8_t last_sequence;
        uint32_t last_seen_ms;
        uint32_t last_heartbeat_ms;
        float interarrival_ewma_ms;
        float interarrival_var_ms2;
        float rate_ewma_hz;
        float timing_cusum;
        float rate_cusum;
        uint16_t duplicate_seq_count;
        uint16_t out_of_order_count;
    };

    SourceProfile *find_or_create_source(uint8_t sysid, uint8_t compid, uint32_t now_ms, bool &new_source);
    static float clamp01(float x);
    static uint8_t sequence_delta(uint8_t previous, uint8_t current);

    float update_timing(SourceProfile &profile, uint32_t now_ms);
    float update_rate(SourceProfile &profile, float rx_rate_hz);

    SourceProfile _sources[MAX_SOURCES];
    Result _result;
};

#endif // AP_IDS_ENABLED
