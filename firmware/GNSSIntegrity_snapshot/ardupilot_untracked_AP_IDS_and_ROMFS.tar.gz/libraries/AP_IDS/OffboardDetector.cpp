/*
  PUSHPAK UAV IDS - external/offboard control anomaly detector

  Detection methods:
    1. Stream freshness/staleness detection: identify a control stream that
       silently becomes sparse without requiring a hard disconnect.
    2. EWMA + variance-normalised change detection on setpoint frequency.
    3. One-sided CUSUM for low-and-slow setpoint-rate manipulation.
    4. Source identity anomaly: unexpected system/component source during
       external control.
    5. Command/vehicle kinematic divergence: compare commanded setpoints with
       measured position/velocity/attitude response.
    6. Burst detection for command flooding / oscillatory setpoint injection.
    7. Flight-mode/arming context correlation to reduce false positives when a
       companion stream is intentionally inactive.
*/
#include "OffboardDetector.h"

#if AP_IDS_ENABLED

#include <AP_Math/AP_Math.h>
#include <math.h>

namespace {

constexpr uint32_t STALE_STREAM_MS = 500U;
constexpr float EWMA_ALPHA = 0.10f;
constexpr float RATE_CUSUM_K = 0.10f;
constexpr float RATE_CUSUM_H = 1.50f;
constexpr float TRACK_CUSUM_K = 0.15f;
constexpr float TRACK_CUSUM_H = 2.00f;
constexpr uint32_t BURST_WINDOW_MS = 300U;
constexpr float RATE_FLOOR_HZ = 1.0f;
constexpr float TRACKING_SUSPECT_M = 3.0f;
constexpr float TRACKING_CONFIRM_M = 10.0f;
constexpr float TRACKING_SUSPECT_MS = 2.0f;
constexpr float TRACKING_CONFIRM_MS = 6.0f;

} // namespace

OffboardDetector::OffboardDetector()
{
    reset();
}

void OffboardDetector::reset()
{
    _initialised = false;
    _last_timestamp_ms = 0;
    _last_source_sysid = 0;
    _last_source_compid = 0;
    _last_setpoint_rate_hz = 0.0f;
    _rate_ewma = 0.0f;
    _rate_var = 0.0f;
    _rate_cusum = 0.0f;
    _tracking_ewma = 0.0f;
    _tracking_var = 0.0f;
    _tracking_cusum = 0.0f;
    _burst_count = 0;
    _result = Result {
        AP_IDS::EVID_NONE,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0,
        0
    };
}

float OffboardDetector::clamp01(float x)
{
    return constrain_float(x, 0.0f, 1.0f);
}

float OffboardDetector::absf(float x)
{
    return fabsf(x);
}

OffboardDetector::Result OffboardDetector::update(const Observation &observation)
{
    Result result = _result;
    result.evidence = AP_IDS::EVID_NONE;
    result.confidence = 0.0f;
    result.stale_stream_score = 0.0f;
    result.rate_anomaly_score = 0.0f;
    result.source_anomaly_score = 0.0f;
    result.tracking_divergence_score = 0.0f;
    result.context_score = 0.0f;
    result.burst_score = 0.0f;
    result.source_sysid = observation.source_sysid;
    result.source_compid = observation.source_compid;

    if (!_initialised) {
        _initialised = true;
        _last_timestamp_ms = observation.timestamp_ms;
        _last_source_sysid = observation.source_sysid;
        _last_source_compid = observation.source_compid;
        _last_setpoint_rate_hz = observation.setpoint_rate_hz;
        _rate_ewma = observation.setpoint_rate_hz;
        _tracking_ewma = fmaxf(absf(observation.position_error_m),
                               absf(observation.velocity_error_ms));
        _burst_count = 1U;
        _result = result;
        return _result;
    }

    const uint32_t dt_ms = observation.timestamp_ms - _last_timestamp_ms;

    if (observation.external_control_active && observation.vehicle_armed &&
        dt_ms > STALE_STREAM_MS) {
        result.stale_stream_score = 0.90f;
        result.evidence |= AP_IDS::EVID_PERSISTENCE;
        result.evidence |= AP_IDS::EVID_RATE_ANOMALY;
    }

    const float rate_delta = observation.setpoint_rate_hz - _rate_ewma;
    _rate_ewma = (1.0f - EWMA_ALPHA) * _rate_ewma +
                 EWMA_ALPHA * observation.setpoint_rate_hz;
    _rate_var = (1.0f - EWMA_ALPHA) *
                (_rate_var + EWMA_ALPHA * rate_delta * rate_delta);
    const float rate_sigma = sqrtf(fmaxf(_rate_var, 0.0f)) + 0.25f;
    const float rate_z = absf(rate_delta) / (3.0f * rate_sigma);

    const float rate_excess =
        (_rate_ewma - observation.setpoint_rate_hz) /
        fmaxf(_rate_ewma, RATE_FLOOR_HZ) - RATE_CUSUM_K;
    _rate_cusum = fmaxf(0.0f, _rate_cusum + rate_excess);
    _rate_cusum = fminf(_rate_cusum, 2.0f * RATE_CUSUM_H);

    result.rate_anomaly_score = clamp01(
        fmaxf(clamp01(rate_z),
              _rate_cusum / (2.0f * RATE_CUSUM_H)));
    if (result.rate_anomaly_score > 0.40f) {
        result.evidence |= AP_IDS::EVID_EWMA_CHANGE;
        result.evidence |= AP_IDS::EVID_CUSUM_CHANGE;
    }

    if (_last_source_sysid != observation.source_sysid ||
        _last_source_compid != observation.source_compid) {
        result.source_anomaly_score = observation.expected_source ? 0.35f : 0.90f;
        result.evidence |= AP_IDS::EVID_SOURCE_ANOMALY;
    } else if (!observation.expected_source && observation.external_control_active) {
        result.source_anomaly_score = 0.75f;
        result.evidence |= AP_IDS::EVID_SOURCE_ANOMALY;
    }

    const float commanded_speed_error =
        absf(observation.commanded_speed_ms - observation.observed_speed_ms);
    const float position_score =
        clamp01(absf(observation.position_error_m) / TRACKING_CONFIRM_M);
    const float velocity_score =
        clamp01(absf(observation.velocity_error_ms) / TRACKING_CONFIRM_MS);
    result.tracking_divergence_score = fmaxf(position_score, velocity_score);

    const float tracking_value = fmaxf(
        absf(observation.position_error_m) / TRACKING_SUSPECT_M,
        fmaxf(absf(observation.velocity_error_ms) / TRACKING_SUSPECT_MS,
              commanded_speed_error / TRACKING_SUSPECT_MS));
    const float tracking_delta = tracking_value - _tracking_ewma;
    _tracking_ewma = (1.0f - EWMA_ALPHA) * _tracking_ewma +
                     EWMA_ALPHA * tracking_value;
    _tracking_var = (1.0f - EWMA_ALPHA) *
                    (_tracking_var + EWMA_ALPHA * tracking_delta * tracking_delta);
    const float tracking_sigma = sqrtf(fmaxf(_tracking_var, 0.0f)) + 0.10f;
    const float tracking_excess =
        tracking_value / fmaxf(_tracking_ewma, 1.0f) - TRACK_CUSUM_K;
    _tracking_cusum = fmaxf(0.0f, _tracking_cusum + tracking_excess);
    _tracking_cusum = fminf(_tracking_cusum, 2.0f * TRACK_CUSUM_H);

    const float tracking_stat =
        fmaxf(clamp01(tracking_delta / (3.0f * tracking_sigma)),
              _tracking_cusum / (2.0f * TRACK_CUSUM_H));
    result.tracking_divergence_score = clamp01(
        0.65f * result.tracking_divergence_score + 0.35f * tracking_stat);
    if (result.tracking_divergence_score > 0.40f) {
        result.evidence |= AP_IDS::EVID_KINEMATIC_MISMATCH;
    }

    if (dt_ms <= BURST_WINDOW_MS) {
        _burst_count = _burst_count < 255U ?
                       static_cast<uint8_t>(_burst_count + 1U) : _burst_count;
    } else {
        _burst_count = 1U;
    }
    result.burst_score = clamp01(static_cast<float>(_burst_count) / 8.0f);
    if (_burst_count >= 8U) {
        result.evidence |= AP_IDS::EVID_RATE_ANOMALY;
    }

    if (observation.vehicle_armed && observation.vehicle_in_guided_mode &&
        observation.external_control_active) {
        result.context_score = 0.80f;
        if (!observation.stream_valid) {
            result.context_score = 1.0f;
            result.evidence |= AP_IDS::EVID_CONTEXT_ANOMALY;
        }
    } else if (observation.vehicle_armed && observation.external_control_active) {
        result.context_score = 0.45f;
    }

    result.confidence = clamp01(
        0.25f * result.stale_stream_score +
        0.20f * result.rate_anomaly_score +
        0.15f * result.source_anomaly_score +
        0.25f * result.tracking_divergence_score +
        0.10f * result.burst_score +
        0.05f * result.context_score);

    _last_timestamp_ms = observation.timestamp_ms;
    _last_source_sysid = observation.source_sysid;
    _last_source_compid = observation.source_compid;
    _last_setpoint_rate_hz = observation.setpoint_rate_hz;

    _result = result;
    return _result;
}

#endif // AP_IDS_ENABLED
