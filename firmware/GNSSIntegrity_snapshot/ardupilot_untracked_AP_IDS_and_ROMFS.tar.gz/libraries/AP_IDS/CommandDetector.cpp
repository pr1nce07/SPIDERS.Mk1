/*
  PUSHPAK UAV IDS - MAVLink command/context anomaly detector

  Detection methods:
    1. Source trust / identity anomaly gating.
    2. Flight-state semantic anomaly detection for sensitive commands.
    3. Per-command inter-arrival EWMA and burst CUSUM (low-and-slow and burst attacks).
    4. Trusted-source parameter baseline using online Welford mean/variance.
    5. Rapid duplicate-command detection for replay/burst-like behaviour.
    6. Evidence fusion without blocking the command path.
*/
#include "CommandDetector.h"

#if AP_IDS_ENABLED

#include <GCS_MAVLink/GCS_MAVLink.h>
#include <AP_Math/AP_Math.h>
#include <math.h>

namespace {

constexpr uint32_t RAPID_DUPLICATE_MS = 250;
constexpr float BURST_BASELINE_MS = 750.0f;
constexpr float BURST_K_MS = 75.0f;
constexpr float BURST_H_MS = 400.0f;
constexpr uint16_t PARAM_BASELINE_MIN_SAMPLES = 8;
constexpr float PARAM_Z_SUSPECT = 3.0f;
constexpr float PARAM_Z_CONFIRM = 6.0f;

} // namespace

CommandDetector::CommandDetector()
{
    reset();
}

void CommandDetector::reset()
{
    for (auto &source : _sources) {
        source = SourceProfile {};
    }
    for (auto &command : _commands) {
        command = CommandProfile {};
    }
    _result = Result {AP_IDS::EVID_NONE, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0};
}

float CommandDetector::clamp01(float x)
{
    return constrain_float(x, 0.0f, 1.0f);
}

bool CommandDetector::nearly_equal(float a, float b, float tolerance)
{
    return fabsf(a - b) <= tolerance;
}

bool CommandDetector::is_sensitive_command(uint16_t command_id)
{
    switch ((MAV_CMD)command_id) {
    case MAV_CMD_COMPONENT_ARM_DISARM:
    case MAV_CMD_DO_SET_MODE:
    case MAV_CMD_DO_MOTOR_TEST:
    case MAV_CMD_DO_PARACHUTE:
    case MAV_CMD_NAV_TAKEOFF:
    case MAV_CMD_NAV_LAND:
    case MAV_CMD_NAV_RETURN_TO_LAUNCH:
    case MAV_CMD_MISSION_START:
    case MAV_CMD_DO_REPOSITION:
    case MAV_CMD_CONDITION_YAW:
    case MAV_CMD_DO_CHANGE_SPEED:
        return true;
    default:
        return false;
    }
}

CommandDetector::SourceProfile *CommandDetector::find_source(
    uint8_t sysid,
    uint8_t compid,
    uint32_t now_ms,
    bool create)
{
    for (auto &source : _sources) {
        if (source.active && source.sysid == sysid && source.compid == compid) {
            source.last_command_ms = now_ms;
            return &source;
        }
    }

    if (!create) {
        return nullptr;
    }

    SourceProfile *candidate = nullptr;
    for (auto &source : _sources) {
        if (!source.active) {
            candidate = &source;
            break;
        }
        if (candidate == nullptr || source.last_command_ms < candidate->last_command_ms) {
            candidate = &source;
        }
    }

    if (candidate == nullptr) {
        return nullptr;
    }

    *candidate = SourceProfile {true, sysid, compid, now_ms, 0};
    return candidate;
}

CommandDetector::CommandProfile *CommandDetector::find_command(
    uint16_t command_id,
    uint32_t now_ms,
    bool create)
{
    for (auto &command : _commands) {
        if (command.active && command.command_id == command_id) {
            return &command;
        }
    }

    if (!create) {
        return nullptr;
    }

    CommandProfile *candidate = nullptr;
    for (auto &command : _commands) {
        if (!command.active) {
            candidate = &command;
            break;
        }
        if (candidate == nullptr || command.last_seen_ms < candidate->last_seen_ms) {
            candidate = &command;
        }
    }

    if (candidate == nullptr) {
        return nullptr;
    }

    *candidate = CommandProfile {};
    candidate->active = true;
    candidate->command_id = command_id;
    candidate->last_seen_ms = now_ms;
    return candidate;
}

float CommandDetector::update_burst(CommandProfile &profile, uint32_t now_ms)
{
    if (profile.last_seen_ms == 0U) {
        profile.last_seen_ms = now_ms;
        return 0.0f;
    }

    const uint32_t raw_dt = now_ms - profile.last_seen_ms;
    profile.last_seen_ms = now_ms;

    if (raw_dt == 0U) {
        profile.burst_cusum = fminf(profile.burst_cusum + 250.0f, 2.0f * BURST_H_MS);
        return 1.0f;
    }

    const float dt = static_cast<float>(raw_dt);
    const float deficit = BURST_BASELINE_MS - dt - BURST_K_MS;
    profile.burst_cusum = fmaxf(0.0f, profile.burst_cusum + deficit);
    profile.burst_cusum = fminf(profile.burst_cusum, 2.0f * BURST_H_MS);
    return clamp01((profile.burst_cusum - BURST_H_MS) / BURST_H_MS);
}

float CommandDetector::update_parameter_baseline(CommandProfile &profile,
                                                 const float *params)
{
    if (profile.parameter_samples < PARAM_BASELINE_MIN_SAMPLES) {
        return 0.0f;
    }

    float max_z = 0.0f;
    for (uint8_t i = 0; i < PARAM_COUNT; i++) {
        const float variance =
            profile.parameter_samples > 1U
            ? profile.parameter_m2[i] / static_cast<float>(profile.parameter_samples - 1U)
            : 0.0f;
        const float sigma = sqrtf(fmaxf(variance, 0.0f));
        if (sigma < 0.05f) {
            if (!nearly_equal(params[i], profile.parameter_mean[i], 0.05f)) {
                max_z = fmaxf(max_z, 2.5f);
            }
            continue;
        }
        max_z = fmaxf(max_z, fabsf(params[i] - profile.parameter_mean[i]) / sigma);
    }

    return clamp01(max_z / PARAM_Z_CONFIRM);
}

float CommandDetector::context_anomaly(const Observation &obs) const
{
    float score = 0.0f;
    const bool sensitive = is_sensitive_command(obs.command_id);

    if (!obs.source_trusted) {
        score = fmaxf(score, sensitive ? 0.70f : 0.30f);
    }

    switch ((MAV_CMD)obs.command_id) {
    case MAV_CMD_COMPONENT_ARM_DISARM:
        // A DISARM request while airborne is a high-risk semantic mismatch.
        if (obs.vehicle_airborne && obs.params[0] < 0.5f) {
            score = fmaxf(score, 0.95f);
        }
        // Repeated ARM commands while already armed can indicate automation
        // abuse or command flooding, but alone are not treated as compromise.
        if (obs.vehicle_armed && obs.params[0] > 0.5f) {
            score = fmaxf(score, 0.30f);
        }
        break;

    case MAV_CMD_DO_MOTOR_TEST:
        if (obs.vehicle_airborne) {
            score = fmaxf(score, 0.98f);
        }
        break;

    case MAV_CMD_DO_PARACHUTE:
        // Parachute enable/disable/release is highly state-sensitive.
        if (obs.vehicle_airborne) {
            score = fmaxf(score, 0.75f);
        }
        break;

    case MAV_CMD_MISSION_START:
        if (obs.mission_running) {
            score = fmaxf(score, 0.70f);
        }
        break;

    case MAV_CMD_DO_SET_MODE:
        // Guided/offboard-type control should not appear unexpectedly when the
        // aircraft has no external control stream expected.
        if (!obs.external_control_expected && obs.params[1] > 0.0f) {
            score = fmaxf(score, 0.55f);
        }
        break;

    default:
        break;
    }

    if (obs.target_sysid != 0U && !obs.source_trusted && sensitive) {
        score = fmaxf(score, 0.80f);
    }

    return clamp01(score);
}

CommandDetector::Result CommandDetector::observe(const Observation &obs)
{
    Result result = _result;
    result.evidence = AP_IDS::EVID_NONE;
    result.confidence = 0.0f;
    result.source_score = 0.0f;
    result.context_score = 0.0f;
    result.burst_score = 0.0f;
    result.parameter_score = 0.0f;
    result.replay_score = 0.0f;
    result.command_id = obs.command_id;

    SourceProfile *source = find_source(
        obs.source_sysid, obs.source_compid, obs.time_ms, true);
    if (source != nullptr) {
        source->command_count++;
        if (!obs.source_trusted) {
            result.source_score = is_sensitive_command(obs.command_id) ? 0.85f : 0.45f;
        }
    }

    CommandProfile *profile = find_command(obs.command_id, obs.time_ms, true);
    if (profile == nullptr) {
        result.confidence = 0.45f;
        result.evidence = AP_IDS::EVID_CONTEXT_ANOMALY;
        _result = result;
        return _result;
    }

    const uint32_t time_since_last = obs.time_ms - profile->last_seen_ms;
    if (profile->count > 0U && time_since_last <= RAPID_DUPLICATE_MS) {
        result.replay_score = 1.0f;
        result.evidence |= AP_IDS::EVID_SEQUENCE_ANOMALY;
    }

    result.burst_score = profile->count == 0U ? 0.0f : update_burst(*profile, obs.time_ms);
    result.context_score = context_anomaly(obs);
    result.parameter_score = update_parameter_baseline(*profile, obs.params);

    if (result.source_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_SOURCE_ANOMALY;
    }
    if (result.context_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_CONTEXT_ANOMALY;
    }
    if (result.burst_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_RATE_ANOMALY;
    }
    if (result.parameter_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_ROBUST_DEVIATION;
    }

    const float parameter_weight = result.parameter_score >= 0.70f ? 0.20f : 0.14f;
    float confidence =
        0.28f * result.source_score +
        0.30f * result.context_score +
        0.18f * result.burst_score +
        parameter_weight * result.parameter_score +
        0.12f * result.replay_score;

    // A sensitive command from an unknown/untrusted source plus either a rapid
    // duplicate or a semantic mismatch is materially stronger than novelty alone.
    if (is_sensitive_command(obs.command_id) &&
        !obs.source_trusted &&
        (result.context_score > 0.50f || result.replay_score > 0.50f)) {
        confidence = fmaxf(confidence, 0.80f);
    }

    // Learn command parameter baselines only from trusted sources. This prevents
    // a hostile command stream from poisoning its own reference distribution.
    if (obs.source_trusted) {
        const uint16_t next = static_cast<uint16_t>(profile->parameter_samples + 1U);
        for (uint8_t i = 0; i < PARAM_COUNT; i++) {
            const float x = obs.params[i];
            const float delta = x - profile->parameter_mean[i];
            profile->parameter_mean[i] += delta / static_cast<float>(next);
            const float delta2 = x - profile->parameter_mean[i];
            profile->parameter_m2[i] += delta * delta2;
        }
        profile->parameter_samples = next;
    }

    profile->count++;
    _result = result;
    _result.confidence = clamp01(confidence);
    return _result;
}

#endif // AP_IDS_ENABLED
