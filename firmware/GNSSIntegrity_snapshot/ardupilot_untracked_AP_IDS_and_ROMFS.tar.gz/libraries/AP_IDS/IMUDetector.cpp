/*
  PUSHPAK UAV IDS - redundant IMU consistency detector

  Detection methods:
    1. Pairwise accelerometer and gyro residuals.
    2. Leave-one-out sensor consensus: identify a single outlier against the
       other IMUs rather than comparing only to a fixed threshold.
    3. EWMA + CUSUM accumulation for slow bias injection / drift.
    4. Sensor-health corroboration.
    5. Primary-sensor selection change as a contextual anomaly.
    6. Persistence through the shared AP_IDS layer.
*/
#include "IMUDetector.h"

// odr-use (MIN takes a reference): needs an out-of-class definition in C++11 builds
constexpr uint8_t IMUDetector::MAX_IMUS;

#if AP_IDS_ENABLED

#include <AP_Math/AP_Math.h>
#include <math.h>

namespace {

constexpr float ACCEL_SUSPECT_MS2 = 0.75f;
constexpr float ACCEL_CONFIRM_MS2 = 2.0f;
constexpr float GYRO_SUSPECT_RAD = 0.10f;
constexpr float GYRO_CONFIRM_RAD = 0.35f;
constexpr float CUSUM_ACCEL_K = 0.08f;
constexpr float CUSUM_ACCEL_H = 0.75f;
constexpr float CUSUM_GYRO_K = 0.01f;
constexpr float CUSUM_GYRO_H = 0.10f;

} // namespace

IMUDetector::IMUDetector()
{
    reset();
}

void IMUDetector::reset()
{
    for (auto &pair : _pairs) {
        pair = PairTrack {};
    }
    _previous_primary_accel = 0;
    _previous_primary_gyro = 0;
    _selection_initialised = false;
    _result = Result {
        AP_IDS::EVID_NONE,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        255,
        255
    };
}

float IMUDetector::clamp01(float x)
{
    return constrain_float(x, 0.0f, 1.0f);
}

float IMUDetector::magnitude3(const Vector3f &v)
{
    return sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
}

float IMUDetector::pair_score(PairTrack &track,
                              float accel_residual,
                              float gyro_residual)
{
    if (!track.initialised) {
        track.accel_ewma = accel_residual;
        track.gyro_ewma = gyro_residual;
        track.accel_var = 0.0f;
        track.gyro_var = 0.0f;
        track.accel_cusum = 0.0f;
        track.gyro_cusum = 0.0f;
        track.initialised = true;
        return 0.0f;
    }

    constexpr float alpha = 0.10f;

    const float accel_error = accel_residual - track.accel_ewma;
    const float gyro_error = gyro_residual - track.gyro_ewma;

    track.accel_ewma = (1.0f - alpha) * track.accel_ewma + alpha * accel_residual;
    track.gyro_ewma = (1.0f - alpha) * track.gyro_ewma + alpha * gyro_residual;
    track.accel_var = (1.0f - alpha) *
                      (track.accel_var + alpha * accel_error * accel_error);
    track.gyro_var = (1.0f - alpha) *
                     (track.gyro_var + alpha * gyro_error * gyro_error);

    const float accel_sigma = sqrtf(fmaxf(track.accel_var, 0.0f)) + 0.05f;
    const float gyro_sigma = sqrtf(fmaxf(track.gyro_var, 0.0f)) + 0.01f;
    const float accel_z = fabsf(accel_error) / (3.0f * accel_sigma);
    const float gyro_z = fabsf(gyro_error) / (3.0f * gyro_sigma);

    const float accel_excess = accel_residual - track.accel_ewma - CUSUM_ACCEL_K;
    const float gyro_excess = gyro_residual - track.gyro_ewma - CUSUM_GYRO_K;
    track.accel_cusum = fmaxf(0.0f, track.accel_cusum + accel_excess);
    track.gyro_cusum = fmaxf(0.0f, track.gyro_cusum + gyro_excess);
    track.accel_cusum = fminf(track.accel_cusum, 2.0f * CUSUM_ACCEL_H);
    track.gyro_cusum = fminf(track.gyro_cusum, 2.0f * CUSUM_GYRO_H);

    const float cusum_accel = clamp01(
        (track.accel_cusum - CUSUM_ACCEL_H) / CUSUM_ACCEL_H);
    const float cusum_gyro = clamp01(
        (track.gyro_cusum - CUSUM_GYRO_H) / CUSUM_GYRO_H);

    return clamp01(
        fmaxf(fmaxf(accel_residual / ACCEL_CONFIRM_MS2,
                    gyro_residual / GYRO_CONFIRM_RAD),
              fmaxf(clamp01(accel_z), clamp01(gyro_z)) * 0.8f +
              0.2f * fmaxf(cusum_accel, cusum_gyro)));
}

IMUDetector::Result IMUDetector::update(const AP_InertialSensor &ins)
{
    Result result = _result;
    result.evidence = AP_IDS::EVID_NONE;
    result.confidence = 0.0f;
    result.accel_divergence = 0.0f;
    result.gyro_divergence = 0.0f;
    result.consensus_score = 0.0f;
    result.bias_drift_score = 0.0f;
    result.health_score = 0.0f;
    result.selection_change_score = 0.0f;
    result.accel_outlier = 255;
    result.gyro_outlier = 255;

    const uint8_t accel_count = ins.get_accel_count();
    const uint8_t gyro_count = ins.get_gyro_count();
    const uint8_t count = MIN(MAX_IMUS, MAX(accel_count, gyro_count));

    if (count < 2U) {
        _result = result;
        return _result;
    }

    float max_pair_score = 0.0f;
    uint8_t pair_slot = 0;
    for (uint8_t i = 0; i < count; i++) {
        for (uint8_t j = static_cast<uint8_t>(i + 1U); j < count; j++) {
            if (pair_slot >= MAX_PAIRS) {
                break;
            }

            const float accel_residual =
                magnitude3(ins.get_accel(i) - ins.get_accel(j));
            const float gyro_residual =
                magnitude3(ins.get_gyro(i) - ins.get_gyro(j));

            result.accel_divergence = fmaxf(result.accel_divergence,
                                            accel_residual / ACCEL_CONFIRM_MS2);
            result.gyro_divergence = fmaxf(result.gyro_divergence,
                                           gyro_residual / GYRO_CONFIRM_RAD);

            const float pair_score_value = pair_score(
                _pairs[pair_slot], accel_residual, gyro_residual);
            max_pair_score = fmaxf(max_pair_score, pair_score_value);
            result.bias_drift_score = fmaxf(
                result.bias_drift_score,
                fmaxf(_pairs[pair_slot].accel_cusum / (2.0f * CUSUM_ACCEL_H),
                      _pairs[pair_slot].gyro_cusum / (2.0f * CUSUM_GYRO_H)));
            pair_slot++;
        }
    }

    // Leave-one-out consensus: for each accelerometer/gyro, compare it to the
    // mean of the other sensors. This identifies a single faulty/deceptive
    // sensor even when the raw difference is otherwise within a loose threshold.
    float worst_accel_consensus = 0.0f;
    float worst_gyro_consensus = 0.0f;
    if (accel_count >= 3U) {
        for (uint8_t i = 0; i < accel_count && i < MAX_IMUS; i++) {
            Vector3f other_sum;
            uint8_t other_count = 0;
            for (uint8_t j = 0; j < accel_count && j < MAX_IMUS; j++) {
                if (i == j) continue;
                other_sum += ins.get_accel(j);
                other_count++;
            }
            if (other_count > 0U) {
                other_sum /= static_cast<float>(other_count);
                const float score = clamp01(
                    magnitude3(ins.get_accel(i) - other_sum) / ACCEL_CONFIRM_MS2);
                if (score > worst_accel_consensus) {
                    worst_accel_consensus = score;
                    result.accel_outlier = i;
                }
            }
        }
    } else {
        // With two IMUs, the pairwise residual is the consensus signal.
        worst_accel_consensus = clamp01(result.accel_divergence);
    }

    if (gyro_count >= 3U) {
        for (uint8_t i = 0; i < gyro_count && i < MAX_IMUS; i++) {
            Vector3f other_sum;
            uint8_t other_count = 0;
            for (uint8_t j = 0; j < gyro_count && j < MAX_IMUS; j++) {
                if (i == j) continue;
                other_sum += ins.get_gyro(j);
                other_count++;
            }
            if (other_count > 0U) {
                other_sum /= static_cast<float>(other_count);
                const float score = clamp01(
                    magnitude3(ins.get_gyro(i) - other_sum) / GYRO_CONFIRM_RAD);
                if (score > worst_gyro_consensus) {
                    worst_gyro_consensus = score;
                    result.gyro_outlier = i;
                }
            }
        }
    } else {
        worst_gyro_consensus = clamp01(result.gyro_divergence);
    }

    result.consensus_score = fmaxf(worst_accel_consensus, worst_gyro_consensus);

    // ArduPilot already performs its own consistency checks. Use those checks as
    // corroborating evidence instead of duplicating their internal thresholds.
    if (!ins.accels_consistent(ACCEL_SUSPECT_MS2)) {
        result.health_score = fmaxf(result.health_score, 0.60f);
    }
    if (!ins.gyros_consistent(2)) {
        result.health_score = fmaxf(result.health_score, 0.60f);
    }

    if (!ins.get_accel_health_all() || !ins.get_gyro_health_all()) {
        result.health_score = fmaxf(result.health_score, 0.85f);
        result.evidence |= AP_IDS::EVID_DEGRADED_SENSOR;
    }

    const uint8_t primary_accel = ins.get_first_usable_accel();
    const uint8_t primary_gyro = ins.get_first_usable_gyro();
    if (_selection_initialised &&
        (primary_accel != _previous_primary_accel || primary_gyro != _previous_primary_gyro)) {
        result.selection_change_score = 0.70f;
        result.evidence |= AP_IDS::EVID_CONTEXT_ANOMALY;
    }
    _previous_primary_accel = primary_accel;
    _previous_primary_gyro = primary_gyro;
    _selection_initialised = true;

    if (result.accel_divergence > 0.30f || result.consensus_score > 0.30f) {
        result.evidence |= AP_IDS::EVID_CROSS_SENSOR;
    }
    if (result.bias_drift_score > 0.20f) {
        result.evidence |= AP_IDS::EVID_CUSUM_CHANGE;
    }

    const float threshold_score = fmaxf(
        fmaxf(clamp01(result.accel_divergence), clamp01(result.gyro_divergence)),
        fmaxf(result.consensus_score, result.bias_drift_score));

    result.confidence = clamp01(
        0.30f * threshold_score +
        0.25f * max_pair_score +
        0.20f * result.consensus_score +
        0.15f * result.health_score +
        0.10f * result.selection_change_score);

    _result = result;
    return _result;
}

#endif // AP_IDS_ENABLED
