/*
  PUSHPAK UAV IDS - mission integrity detector

  Read-only detector for unexpected mission mutation, current-item jumps,
  mission-size changes and suspicious mission rewrites during execution.
*/
#pragma once

#include <AP_Mission/AP_Mission.h>
#include <stdint.h>

#include "AP_IDS.h"

#if AP_IDS_ENABLED

class MissionDetector
{
public:
    struct Result {
        uint16_t evidence;
        float confidence;
        float mission_change_score;
        float current_item_jump_score;
        float command_sequence_score;
        float flight_context_score;
        uint32_t mission_hash;
        uint16_t command_count;
        uint16_t current_index;
    };

    MissionDetector();
    void reset();
    Result update(const AP_Mission &mission, bool armed, bool mission_mode);

    const Result &result() const { return _result; }

private:
    static uint32_t fnv1a_mix(uint32_t hash, const void *data, uint32_t len);
    static float clamp01(float x);

    uint32_t calculate_hash(const AP_Mission &mission) const;
    float update_change_persistence(bool changed);

    bool _initialised;
    uint32_t _baseline_hash;
    uint16_t _baseline_count;
    uint16_t _previous_index;
    uint16_t _previous_count;
    uint16_t _previous_command_id;
    float _change_persistence;
    Result _result;
};

#endif // AP_IDS_ENABLED
