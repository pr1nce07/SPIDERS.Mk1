/*
  PUSHPAK UAV IDS -> GCS reporting bridge
*/

#include "AP_IDSGCS.h"
#include <string.h>
#include <GCS_MAVLink/GCS_config.h>  // defines HAL_GCS_ENABLED

#if defined(HAL_GCS_ENABLED) && HAL_GCS_ENABLED

#include <AP_HAL/AP_HAL.h>
#include <GCS_MAVLink/GCS.h>

static uint32_t last_event_id = 0;
static uint8_t last_detector_code = 0xFFU;

const char *AP_IDSGCS::short_detector(const char *detector)
{
    if (detector == nullptr) {
        return nullptr;
    }

    if (strcmp(detector, "GPS") == 0) {
        return "GPS";
    }
    if (strcmp(detector, "IMU") == 0) {
        return "IMU";
    }
    if ((strcmp(detector, "MISSION") == 0) || (strcmp(detector, "MIS") == 0)) {
        return "MIS";
    }
    if ((strcmp(detector, "MAVLINK") == 0) || (strcmp(detector, "MAV") == 0)) {
        return "MAV";
    }
    if ((strcmp(detector, "COMMAND") == 0) || (strcmp(detector, "CMD") == 0)) {
        return "CMD";
    }
    if ((strcmp(detector, "RC") == 0) || (strcmp(detector, "RC_LINK") == 0)) {
        return "RC";
    }
    if ((strcmp(detector, "PARAMETER") == 0) || (strcmp(detector, "PAR") == 0)) {
        return "PAR";
    }
    if ((strcmp(detector, "OFFBOARD") == 0) || (strcmp(detector, "OFF") == 0)) {
        return "OFF";
    }

    return nullptr;
}

uint8_t AP_IDSGCS::mav_severity(uint8_t level)
{
    switch (level) {
    case 4:
        return MAV_SEVERITY_CRITICAL;
    case 3:
        return MAV_SEVERITY_ERROR;
    case 2:
        return MAV_SEVERITY_WARNING;
    case 1:
        return MAV_SEVERITY_NOTICE;
    default:
        return MAV_SEVERITY_INFO;
    }
}

bool AP_IDSGCS::report_confirmed(const char *detector,
                                 uint8_t level,
                                 float confidence,
                                 uint16_t evidence,
                                 float primary_metric,
                                 uint8_t source_instance,
                                 uint32_t event_id)
{
    (void)primary_metric;

    const char *name = short_detector(detector);
    if (name == nullptr || level < 1U || level > 4U || event_id == 0U) {
        return false;
    }

    if (confidence < 0.0f) {
        confidence = 0.0f;
    } else if (confidence > 1.0f) {
        confidence = 1.0f;
    }

    // The same detector/event can be presented to Lua on every script tick.
    // Emit it only once from the firmware bridge.
    uint8_t detector_code = 0xFFU;
    if (strcmp(name, "GPS") == 0) { detector_code = 0U; }
    else if (strcmp(name, "IMU") == 0) { detector_code = 1U; }
    else if (strcmp(name, "MIS") == 0) { detector_code = 2U; }
    else if (strcmp(name, "MAV") == 0) { detector_code = 3U; }
    else if (strcmp(name, "CMD") == 0) { detector_code = 4U; }
    else if (strcmp(name, "RC") == 0) { detector_code = 5U; }
    else if (strcmp(name, "PAR") == 0) { detector_code = 6U; }
    else if (strcmp(name, "OFF") == 0) { detector_code = 7U; }

    if (event_id == last_event_id && detector_code == last_detector_code) {
        return false;
    }

    const uint8_t confidence_pct = static_cast<uint8_t>(confidence * 100.0f + 0.5f);
    const unsigned long event_hex = static_cast<unsigned long>(event_id & 0xFFFFFFU);

    // Keep this text <= MAVLINK_MSG_STATUSTEXT_FIELD_TEXT_LEN (50 bytes).
    GCS_SEND_TEXT(static_cast<MAV_SEVERITY>(mav_severity(level)),
                  "[PIDS] %s THREAT LV%u C%u E%04X S%u LUA I%06lX",
                  name,
                  static_cast<unsigned>(level),
                  static_cast<unsigned>(confidence_pct),
                  static_cast<unsigned>(evidence),
                  static_cast<unsigned>(source_instance),
                  event_hex);

    last_event_id = event_id;
    last_detector_code = detector_code;
    return true;
}

#else

bool AP_IDSGCS::report_confirmed(const char *,
                                 uint8_t,
                                 float,
                                 uint16_t,
                                 float,
                                 uint8_t,
                                 uint32_t)
{
    return false;
}

#endif
