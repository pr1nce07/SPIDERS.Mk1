/*
  PUSHPAK UAV IDS - GPS / INS anomaly detector
  Target: ArduPilot 4.7.x

  Detection combines independent indicators instead of declaring spoofing from
  latitude/longitude alone. The detector is intentionally read-only.
*/
#pragma once

#include <AP_AHRS/AP_AHRS.h>
#include <AP_GPS/AP_GPS.h>
#include <stdint.h>

#include "AP_IDS.h"

#if AP_IDS_ENABLED

class GPSDetector
{
public:
    static constexpr uint8_t GPS_HISTORY_SIZE = 16;
    static constexpr uint8_t GPS_MAX_TRACKED = 3;

    struct Result {
        bool valid;
        uint16_t evidence;
        float confidence;
        float position_residual_m;
        float velocity_residual_mps;
        float cross_gps_residual_m;
        float robust_z;
        float cusum;
        uint8_t persistence;
    };

    GPSDetector();

    void reset();

    // Call at the GPS update cadence (normally >= 10 Hz).
    Result update(const AP_GPS &gps, const AP_AHRS &ahrs);

    const Result &result() const { return _result; }

private:
    struct Track {
        float residual_history[GPS_HISTORY_SIZE];
        uint8_t history_count;
        uint8_t history_head;
        float ewma;
        float ewma_var;
        float cusum_pos;
        float cusum_neg;
        float previous_residual;
        uint32_t previous_ms;
        uint8_t persistence;
        bool initialised;
    };

    static float magnitude2(const Vector2f &v);
    static float magnitude3(const Vector3f &v);
    static float clamp01(float x);
    static float median(float *values, uint8_t count);
    static float robust_zscore(float sample, const Track &track);
    static void push_history(Track &track, float value);
    static float ewma_score(Track &track, float sample);
    static float cusum_score(Track &track, float sample);

    float position_consistency(const AP_GPS &gps,
                               const AP_AHRS &ahrs,
                               uint8_t instance,
                               float &residual_m);

    float velocity_consistency(const AP_GPS &gps,
                               const AP_AHRS &ahrs,
                               uint8_t instance,
                               float &residual_mps);

    float cross_receiver_consistency(const AP_GPS &gps,
                                     uint8_t primary,
                                     float &cross_residual_m);

    float quality_consistency(const AP_GPS &gps, uint8_t instance);

    float reset_artifact_penalty(const AP_AHRS &ahrs);

    Track _tracks[GPS_MAX_TRACKED];
    Result _result;
};

#endif // AP_IDS_ENABLED
