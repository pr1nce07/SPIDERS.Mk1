/*
  PUSHPAK UAV IDS - RC / telemetry-link anomaly detector

  Detection methods:
    1. EWMA tracking of link quality and loss ratios.
    2. One-sided CUSUM for gradual degradation / low-and-slow jamming.
    3. Sudden-loss detector for abrupt RF disconnects.
    4. Cross-link consistency: RC and telemetry should not fail identically
       unless there is a shared link/environmental cause.
    5. Heartbeat-gap correlation.
    6. Failsafe-aware evidence fusion and bounded persistence.
*/
#include "RCDetector.h"

#if AP_IDS_ENABLED

#include <AP_Math/AP_Math.h>
#include <math.h>

namespace {

constexpr float QUALITY_ALPHA = 0.10f;
constexpr float LOSS_ALPHA = 0.08f;
constexpr float QUALITY_CUSUM_K = 0.025f;
constexpr float QUALITY_CUSUM_H = 0.20f;
constexpr float LOSS_CUSUM_K = 0.05f;
constexpr float LOSS_CUSUM_H = 0.35f;
constexpr float HEARTBEAT_GAP_SUSPECT_MS = 1200.0f;
constexpr float HEARTBEAT_GAP_CONFIRM_MS = 3000.0f;
constexpr float SUDDEN_QUALITY_DROP = 0.40f;

} // namespace

RCDetector::RCDetector()
{
    reset();
}

void RCDetector::reset()
{
    _quality_ewma = 0.0f;
    _quality_var = 0.0f;
    _quality_cusum = 0.0f;
    _loss_ewma = 0.0f;
    _loss_cusum = 0.0f;
    _last_ms = 0;
    _degradation_persistence = 0;
    _initialised = false;
    _result = Result {AP_IDS::EVID_NONE, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
}

float RCDetector::clamp01(float x)
{
    return constrain_float(x, 0.0f, 1.0f);
}

RCDetector::Result RCDetector::observe(const Observation &obs)
{
    Result result = _result;
    result.evidence = AP_IDS::EVID_NONE;
    result.confidence = 0.0f;
    result.gradual_degradation = 0.0f;
    result.sudden_loss = 0.0f;
    result.cross_link_mismatch = 0.0f;
    result.heartbeat_anomaly = 0.0f;
    result.quality_anomaly = 0.0f;

    const float quality = clamp01(obs.link_quality);
    const float rc_loss = clamp01(obs.rc_loss_ratio);
    const float telemetry_loss = clamp01(obs.telemetry_loss_ratio);

    if (!_initialised) {
        _quality_ewma = quality;
        _loss_ewma = fmaxf(rc_loss, telemetry_loss);
        _last_ms = obs.time_ms;
        _initialised = true;
        _result = result;
        return _result;
    }

    const float quality_error = quality - _quality_ewma;
    _quality_ewma = (1.0f - QUALITY_ALPHA) * _quality_ewma + QUALITY_ALPHA * quality;
    _quality_var = (1.0f - QUALITY_ALPHA) *
                   (_quality_var + QUALITY_ALPHA * quality_error * quality_error);

    const float combined_loss = fmaxf(rc_loss, telemetry_loss);
    _loss_ewma = (1.0f - LOSS_ALPHA) * _loss_ewma + LOSS_ALPHA * combined_loss;

    // CUSUM on loss and quality deficit catches a slow degradation that may
    // never cross a single instantaneous threshold.
    const float quality_deficit = _quality_ewma - quality - QUALITY_CUSUM_K;
    _quality_cusum = fmaxf(0.0f, _quality_cusum + quality_deficit);
    _quality_cusum = fminf(_quality_cusum, 2.0f * QUALITY_CUSUM_H);

    const float loss_excess = combined_loss - _loss_ewma - LOSS_CUSUM_K;
    _loss_cusum = fmaxf(0.0f, _loss_cusum + loss_excess);
    _loss_cusum = fminf(_loss_cusum, 2.0f * LOSS_CUSUM_H);

    result.gradual_degradation = clamp01(
        fmaxf((_quality_cusum - QUALITY_CUSUM_H) / QUALITY_CUSUM_H,
              (_loss_cusum - LOSS_CUSUM_H) / LOSS_CUSUM_H));

    const float recent_quality_drop = fmaxf(0.0f, _quality_ewma - quality);
    result.sudden_loss = clamp01(recent_quality_drop / SUDDEN_QUALITY_DROP);
    if (!obs.rc_link_active || !obs.telemetry_link_active) {
        result.sudden_loss = fmaxf(result.sudden_loss, 0.75f);
    }

    // Shared-link failure should affect RC and telemetry together. A mismatch
    // (one healthy while the other fails) is useful to distinguish a selective
    // RF/control-path issue from a total radio outage.
    result.cross_link_mismatch = clamp01(
        fabsf(obs.rc_loss_ratio - obs.telemetry_loss_ratio));

    if (obs.heartbeat_gap_ms >= HEARTBEAT_GAP_SUSPECT_MS) {
        result.heartbeat_anomaly = clamp01(
            (static_cast<float>(obs.heartbeat_gap_ms) - HEARTBEAT_GAP_SUSPECT_MS) /
            (HEARTBEAT_GAP_CONFIRM_MS - HEARTBEAT_GAP_SUSPECT_MS));
    }

    const float quality_sigma = sqrtf(fmaxf(_quality_var, 0.0f)) + 0.05f;
    result.quality_anomaly = clamp01(
        fmaxf(recent_quality_drop / (3.0f * quality_sigma), combined_loss));

    if (result.gradual_degradation > 0.20f) {
        result.evidence |= AP_IDS::EVID_EWMA_CHANGE;
        result.evidence |= AP_IDS::EVID_CUSUM_CHANGE;
    }
    if (result.sudden_loss > 0.40f) {
        result.evidence |= AP_IDS::EVID_RATE_ANOMALY;
    }
    if (result.cross_link_mismatch > 0.30f) {
        result.evidence |= AP_IDS::EVID_CROSS_SENSOR;
    }
    if (result.heartbeat_anomaly > 0.20f) {
        result.evidence |= AP_IDS::EVID_RATE_ANOMALY;
    }
    if (result.quality_anomaly > 0.30f) {
        result.evidence |= AP_IDS::EVID_DEGRADED_SENSOR;
    }

    float confidence =
        0.30f * result.gradual_degradation +
        0.23f * result.sudden_loss +
        0.12f * result.cross_link_mismatch +
        0.20f * result.heartbeat_anomaly +
        0.15f * result.quality_anomaly;

    if (obs.failsafe_active) {
        // A failsafe is supporting evidence, not a verdict, because hardware or
        // environmental failures can generate the same condition.
        confidence = fminf(1.0f, confidence + 0.10f);
        result.evidence |= AP_IDS::EVID_CONTEXT_ANOMALY;
    }

    const bool persistent =
        confidence >= 0.50f ||
        result.gradual_degradation >= 0.70f ||
        result.sudden_loss >= 0.85f ||
        result.heartbeat_anomaly >= 0.90f;

    if (persistent) {
        if (_degradation_persistence < 5U) {
            _degradation_persistence++;
        }
        result.evidence |= AP_IDS::EVID_PERSISTENCE;
    } else if (confidence < 0.30f && _degradation_persistence > 0U) {
        _degradation_persistence--;
    }

    if (_degradation_persistence >= 5U) {
        confidence = fmaxf(confidence, 0.85f);
    }

    result.confidence = clamp01(confidence);
    _last_ms = obs.time_ms;
    _result = result;
    return _result;
}

#endif // AP_IDS_ENABLED
