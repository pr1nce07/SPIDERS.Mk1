/*
  PUSHPAK UAV IDS - runtime parameter integrity detector

  Detection methods:
    1. Robust-ish adaptive baseline: per-parameter Welford mean/variance plus
       EWMA, allowing normal parameter-specific magnitude to be learned.
    2. CUSUM change detection for slow parameter drift rather than only large
       instantaneous deltas.
    3. Rate/burst anomaly detection for repeated writes to a parameter over a
       short interval.
    4. Source novelty: parameter changes from a source different from the
       established writer are retained as independent evidence.
    5. Flight-context correlation: sensitive parameter writes while armed are
       weighted more strongly than benign configuration-time edits.
    6. Provenance separation: externally requested changes are not assumed
       malicious; they are retained as context for the higher-level correlator.
*/
#include "ParameterDetector.h"

#if AP_IDS_ENABLED

#include <AP_Math/AP_Math.h>
#include <math.h>

namespace {

constexpr float EWMA_ALPHA = 0.10f;
constexpr float CUSUM_K = 0.20f;
constexpr float CUSUM_H = 3.0f;
constexpr uint32_t BURST_WINDOW_MS = 1500U;
constexpr uint8_t BURST_LIMIT = 4U;
constexpr float SOURCE_CHANGE_SCORE = 0.75f;
constexpr float ARMED_SENSITIVE_SCORE = 0.95f;

} // namespace

ParameterDetector::ParameterDetector()
{
    reset();
}

void ParameterDetector::reset()
{
    for (auto &track : _tracks) {
        track = Track {};
    }
    _result = Result {
        AP_IDS::EVID_NONE,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0,
        0,
        0
    };
}

float ParameterDetector::clamp01(float x)
{
    return constrain_float(x, 0.0f, 1.0f);
}

float ParameterDetector::absf(float x)
{
    return fabsf(x);
}

ParameterDetector::Track *ParameterDetector::find_track(uint32_t parameter_id)
{
    for (auto &track : _tracks) {
        if (track.initialised && track.parameter_id == parameter_id) {
            return &track;
        }
    }
    return nullptr;
}

ParameterDetector::Track *ParameterDetector::allocate_track(uint32_t parameter_id)
{
    // Fixed-size allocation; prefer a free slot and otherwise replace the
    // least-recently-observed slot. There is intentionally no heap use.
    Track *oldest = &_tracks[0];
    for (auto &track : _tracks) {
        if (!track.initialised) {
            track = Track {};
            track.initialised = true;
            track.parameter_id = parameter_id;
            return &track;
        }
        if (track.last_timestamp_ms < oldest->last_timestamp_ms) {
            oldest = &track;
        }
    }

    *oldest = Track {};
    oldest->initialised = true;
    oldest->parameter_id = parameter_id;
    return oldest;
}

ParameterDetector::Result ParameterDetector::observe(const Observation &observation)
{
    Result result = _result;
    result.evidence = AP_IDS::EVID_NONE;
    result.confidence = 0.0f;
    result.value_change_score = 0.0f;
    result.rate_anomaly_score = 0.0f;
    result.context_score = 0.0f;
    result.source_anomaly_score = 0.0f;
    result.burst_score = 0.0f;
    result.parameter_id = observation.parameter_id;
    result.source_sysid = observation.source_sysid;
    result.source_compid = observation.source_compid;

    Track *track = find_track(observation.parameter_id);
    if (track == nullptr) {
        track = allocate_track(observation.parameter_id);
        track->mean = observation.value;
        track->variance = 0.0f;
        track->ewma = observation.value;
        track->cusum = 0.0f;
        track->count = 1U;
        track->last_timestamp_ms = observation.timestamp_ms;
        track->last_source_sysid = observation.source_sysid;
        track->last_source_compid = observation.source_compid;
        _result = result;
        return _result;
    }

    const float delta = observation.value - track->mean;
    const float sigma = sqrtf(fmaxf(track->variance, 0.0f)) + 0.001f;
    const float robust_z = absf(delta) / (3.0f * sigma);

    // Welford-style update, stable for long-running parameter histories.
    track->count++;
    const float n = static_cast<float>(track->count);
    track->mean += delta / n;
    const float delta2 = observation.value - track->mean;
    track->variance = ((n - 2.0f) / fmaxf(n - 1.0f, 1.0f)) * track->variance +
                      (delta * delta2) / n;

    const float ewma_delta = observation.value - track->ewma;
    track->ewma = (1.0f - EWMA_ALPHA) * track->ewma + EWMA_ALPHA * observation.value;

    const float normalized = absf(ewma_delta) / (sigma + 0.001f);
    const float excess = normalized - CUSUM_K;
    track->cusum = fmaxf(0.0f, track->cusum + excess);
    track->cusum = fminf(track->cusum, 2.0f * CUSUM_H);

    result.value_change_score = clamp01(
        fmaxf(clamp01(robust_z),
              clamp01(track->cusum / (2.0f * CUSUM_H))));
    if (result.value_change_score > 0.35f) {
        result.evidence |= AP_IDS::EVID_ROBUST_DEVIATION;
        result.evidence |= AP_IDS::EVID_CUSUM_CHANGE;
    }

    const uint32_t dt = observation.timestamp_ms - track->last_timestamp_ms;
    if (dt > 0U && dt <= BURST_WINDOW_MS) {
        const uint8_t next_burst = track->burst_count < 255U ?
                                   static_cast<uint8_t>(track->burst_count + 1U) :
                                   track->burst_count;
        track->burst_count = next_burst;
    } else {
        track->burst_count = 1U;
    }
    result.burst_score = clamp01(
        static_cast<float>(track->burst_count) / static_cast<float>(BURST_LIMIT));
    if (track->burst_count >= BURST_LIMIT) {
        result.rate_anomaly_score = 0.85f;
        result.evidence |= AP_IDS::EVID_RATE_ANOMALY;
    }

    if (track->last_source_sysid != observation.source_sysid ||
        track->last_source_compid != observation.source_compid) {
        if (track->source_changes < 255U) {
            track->source_changes++;
        }
        result.source_anomaly_score = SOURCE_CHANGE_SCORE;
        result.evidence |= AP_IDS::EVID_SOURCE_ANOMALY;
    }

    if (observation.armed && observation.sensitive) {
        result.context_score = ARMED_SENSITIVE_SCORE;
        result.evidence |= AP_IDS::EVID_CONTEXT_ANOMALY;
    } else if (observation.armed) {
        result.context_score = 0.30f;
    }

    // An external request is useful provenance; do not promote it to an attack
    // solely because it came from a GCS or companion computer.
    if (observation.externally_requested) {
        result.evidence |= AP_IDS::EVID_INTEGRITY_ANOMALY;
    }

    const float combined_change = fmaxf(
        result.value_change_score,
        fmaxf(result.rate_anomaly_score,
              fmaxf(result.source_anomaly_score, result.burst_score)));

    result.confidence = clamp01(
        0.35f * combined_change +
        0.30f * result.context_score +
        0.20f * result.value_change_score +
        0.15f * result.burst_score);

    track->last_timestamp_ms = observation.timestamp_ms;
    track->last_source_sysid = observation.source_sysid;
    track->last_source_compid = observation.source_compid;

    _result = result;
    return _result;
}

#endif // AP_IDS_ENABLED
