/*
  PUSHPAK UAV IDS -> GCS reporting bridge

  Sends confirmed IDS incidents to the GCS using MAVLink STATUSTEXT (#253).
  The report is emitted only when explicitly called by the Lua confirmation
  layer (or another trusted caller).

  Message format (kept <= 50 chars):
    [PIDS] GPS THREAT LV4 C87 E003A S1 LUA I000123

  Fields:
    PIDS  = PUSHPAK IDS
    GPS   = detector (GPS/IMU/MIS/MAV/CMD/RC/PAR/OFF)
    LV4   = IDS severity 1..4 (low..critical)
    C87   = confidence percent
    E003A = evidence bitmask/value in hex
    S1    = source instance
    LUA   = confirmed by Lua layer
    I000123 = event id (hex)
*/
#pragma once

#include <stdint.h>

class AP_IDSGCS
{
public:
    // Returns true if the event was accepted for transmission.
    // detector is one of: GPS, IMU, MISSION/MIS, MAVLINK/MAV,
    // COMMAND/CMD, RC/RC_LINK, PARAMETER/PAR, OFFBOARD/OFF.
    // level: 1=low, 2=medium, 3=high, 4=critical.
    // confidence is expected in [0,1].
    // event_id must be non-zero and is used to deduplicate repeated Lua calls.
    static bool report_confirmed(const char *detector,
                                 uint8_t level,
                                 float confidence,
                                 uint16_t evidence,
                                 float primary_metric,
                                 uint8_t source_instance,
                                 uint32_t event_id);

private:
    static const char *short_detector(const char *detector);
    static uint8_t mav_severity(uint8_t level);
};
