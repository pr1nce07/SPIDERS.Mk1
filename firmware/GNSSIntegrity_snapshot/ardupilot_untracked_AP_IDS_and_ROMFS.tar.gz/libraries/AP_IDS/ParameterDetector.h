/*
  PUSHPAK UAV IDS - runtime parameter integrity detector

  The detector is deliberately fed normalized parameter-change observations.
  This keeps the IDS independent of the exact AP_Param write path while still
  allowing an ArduPilot adapter to report every accepted runtime change.
*/
#pragma once

#include <stdint.h>

#include "AP_IDS.h"

#if AP_IDS_ENABLED

class ParameterDetector
{
public:
    static constexpr uint8_t MAX_TRACKED = 12;

    struct Observation {
        uint32_t parameter_id;
        float value;
        uint8_t source_sysid;
        uint8_t source_compid;
        bool armed;
        bool sensitive;
        bool externally_requested;
        uint32_t timestamp_ms;
    };

    struct Result {
        uint16_t evidence;
        float confidence;
        float value_change_score;
        float rate_anomaly_score;
        float context_score;
        float source_anomaly_score;
        float burst_score;
        uint32_t parameter_id;
        uint8_t source_sysid;
        uint8_t source_compid;
    };

    ParameterDetector();
    void reset();
    Result observe(const Observation &observation);

    const Result &result() const { return _result; }

private:
    struct Track {
        bool initialised;
        uint32_t parameter_id;
        float mean;
        float variance;
        float ewma;
        float cusum;
        uint32_t count;
        uint32_t last_timestamp_ms;
        uint8_t last_source_sysid;
        uint8_t last_source_compid;
        uint8_t source_changes;
        uint8_t burst_count;
    };

    static float clamp01(float x);
    static float absf(float x);
    Track *find_track(uint32_t parameter_id);
    Track *allocate_track(uint32_t parameter_id);

    Track _tracks[MAX_TRACKED];
    Result _result;
};

#endif // AP_IDS_ENABLED
